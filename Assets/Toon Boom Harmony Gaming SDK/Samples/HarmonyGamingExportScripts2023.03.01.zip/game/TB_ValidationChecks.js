var NodeUtil = require("./TB_NodeUtil.js");
var Iter = require("./TB_Iter.js").Iter;

/**
 * @type {{ problem: string, suggestion: string, evaluate: () => { affected?: NodePath[], selected: NodePath }[], resolve?: (nodeSelection: NodePath[]) => string}[]} nodeSelection
 */
var exportRules = [
  {
    problem: translator.tr("Unsupported node found outside of bake_group"),
    suggestion: translator.tr("Move unsupported node into bake_group"),
    evaluate: function () {
      var writePath = NodeUtil.findFirstWriteNode();
      if (writePath == null)
        return [];
      var invalidNodes = new NodeUtil.InputScan(writePath, {
        shouldEnterGroupNode: function (nodePath) {
          return NodeUtil.getNodeGameTag(nodePath) != "bake";
        },
        isMatch: function (nodePath) {
          return NodeUtil.getNodeGameTag(nodePath) == "invalid";
        }
      }).toArray();
      if (invalidNodes.length == 0)
        return [];
      MessageLog.trace("Invalid nodes: " + invalidNodes.map(function (nodePath) { return node.type(nodePath); }).join(", "));
      return invalidNodes.map(function (nodePath) { return { selected: nodePath }; });
    }
  },
  {
    problem: translator.tr("Multiple top nodes found"),
    suggestion: translator.tr("Create a new master peg and assign all current top nodes to it"),
    evaluate: function () {
      var topNodes = NodeUtil.findTopNodes();
      if (topNodes.length == 1)
        return [];
      return topNodes.map(function (nodePath) { return { selected: nodePath, affected: topNodes }; });
    },
    resolve: function (nodeSelection) {
      var coord = {
        x: node.coordX(nodeSelection[0]),
        y: node.coordY(nodeSelection[0]),
        z: node.coordZ(nodeSelection[0]),
      };
      var masterPegPath = node.add(node.root(), "Master-P", "PEG", coord.x, coord.y - 100, coord.z + 1);
      nodeSelection.forEach(function (nodePath) {
        node.link(masterPegPath, 0, nodePath, 0);
      });
      return translator.tr("Added new master peg");
    }
  },
  {
    problem: translator.tr("No write node found"),
    suggestion: translator.tr("Create a new write node and use input of display as input."),
    evaluate: function () {
      var writePath = NodeUtil.findFirstWriteNode();
      if (writePath != null)
        return [];
      var displayPath = NodeUtil.findFirstDisplayNode();
      if (displayPath == null)
        return [];
      return [{ selected: displayPath }];
    },
    resolve: function (nodeSelection) {
      var displayPath = nodeSelection[0];
      var parent = node.parentNode(displayPath);
      var coord = {
        x: node.coordX(displayPath),
        y: node.coordY(displayPath),
        z: node.coordZ(displayPath),
      };
      var writePath = node.add(parent, "Write", "WRITE", coord.x + 100, coord.y, coord.z + 1);
      node.link(node.srcNode(displayPath, 0), 0, writePath, 0);
      return translator.tr("Added new Write node");
    }
  }
];

// TODO: Implement more rules.
// }, {
//   problem: translator.tr("bake_group found with more than one input Transformation"),
//   suggestion: translator.tr("Remove all but one input Transformation from bake_group"),
// }, {
//   problem: translator.tr("bake_group found with more than one output Image"),
//   suggestion: translator.tr("Remove all but one output Image from bake_group"),
// }, {
//   problem: translator.tr("Cutters cannot receive other Cutters as input"),
//   suggestion: translator.tr("Move unsupported structure into bake_group"),
// }, {
//   problem: translator.tr("All cutter inputs must be deformed together"),
//   suggestion: translator.tr("Assign all cutter inputs to the same Deformer"),
// }, {

/**
 * @param {Record<string, boolean>} ignoredNodes
 */
function getIssues(ignoredNodes) {
  return new Iter(exportRules)
    .flatMap(function (rule) {
      var issues = rule.evaluate ? rule.evaluate() : [];
      return issues
        .map(function (issue) {
          if (ignoredNodes[issue.selected])
            return null;
          var affected = issue.affected != null
            ? issue.affected.filter(function (nodePath) { return !ignoredNodes[nodePath]; })
            : [issue.selected];
          if (affected.length == 0)
            return null;
          return {
            problem: rule.problem,
            suggestion: rule.suggestion,
            resolve: rule.resolve,
            selected: issue.selected,
            affected: affected,
          };
        })
        .filter(Iter.notNull);
    })
    .filter(Iter.notNull);
}

exports.validate = function () {
  var issues = getIssues({});
  var ignoredNodes = /**@type {Record<string, boolean>}*/({});
  var cancelled = false;
  var issue;
  while ((issue = issues.shift()) != null && !cancelled)
  {
    var selected = issue.selected;
    var affected = issue.affected;

    // Select all nodes relating to this issue.
    selection.clearSelection();
    selection.addNodeToSelection(selected);
    Action.performForEach("onActionFocusOnSelectionNV()", "Node View");

    // Start UI for the issue.
    var ui = UiLoader.load("TB_ValidationChecks.ui");
    ui.windowTitle += " (" + issues.length + translator.tr(" issues remaining)");
    ui.lblProblem.text = translator.tr("Problem - ") + issue.problem;
    ui.lblSuggestion.text = translator.tr("Suggestion - ") + issue.suggestion;
    ui.lblAffectedNodes.text = translator.tr("Affected Nodes:\n") + issue.affected.join("\n");

    // Handle UI buttons.
    var skip = false;
    cancelled = true;
    if (issue.resolve == undefined)
    {
      ui.btnResolve.setEnabled(false);
    }
    else
    {
      var resolve = issue.resolve;
      ui.btnResolve.clicked.connect(function () {
        ui.close();
        scene.beginUndoRedoAccum(translator.tr("Render Node"));
        var resolution = resolve(affected);
        MessageBox.information(translator.tr("Suggestion applied - ") + resolution);
        cancelled = false;
      });
    }
    ui.btnNextIssue.clicked.connect(function () {
      ui.close();
      skip = true;
      cancelled = false;
    });
    ui.btnIgnore.clicked.connect(function () {
      ui.close();
      cancelled = false;
      ignoredNodes[selected] = true;
    });
    ui.btnCancel.clicked.connect(function () {
      ui.close();
    });

    // Show UI.
    ui.exec();

    // If the user didn't cancel or skip to next issue, get the next set of issues.
    if (!cancelled && !skip)
    {
      issues = getIssues(ignoredNodes);
    }
    else if (skip)
    {
      issues.push(issue);
    }
  }

  return !cancelled;
}