/*
 * Copyright Toon Boom Animation Inc - 2022
 */

type Lookup<T extends string | number | symbol, U> = { [key in T]?: U };

type NodePath = `Top/${string}`;
type AnimationName = `anim.${string}`;
type SkinName = `skin.${string}` | "none";
type SpritePath = `${string}.png`;

type RenderableNodePaths = {
  bake: `Top/${string}`[];
  read: `Top/${string}`[];
};

type NodePathToMeta = Lookup<NodePath, {
  anchorPropMode?: "anchor" | "prop",
  customMetas?: Record<string, string>,
  group?: string,
  skinToAnimationToKeyframes?: Lookup<SkinName, Record<AnimationName, { spriteIdx: number | null, exposure: number }[]>>,
}>;

type Link = {
  in: UniqueNodePath,
  out: {
    nodePath: UniqueNodePath,
    inputPort: number,
    tag: GameNodeTag,
  },
};
type UniqueLink = `${UniqueNodePath}->${UniqueNodePath}`;

type ChainSource = { input: InputToNode | null, ancestorInputs: InputToNode[] };

type InputToNode = { nodePath: `Top/${string}`, inputPort: number };

type PathChain = {
  input: InputToNode;
  siblingInputs: InputToNode[];
}[];

type ProcessedPaletteColor = {
  id: string;
  data: string;
}

type ProcessedPalette = {
  id: string,
  colors: ProcessedPaletteColor[],
};

type LinkGeneratorCallbacks = {
  shouldEnterGroupNode?: (nodePath: NodePath) => boolean,
  shouldDeferInputToSeperateChain?: (nodePath: NodePath, inputPort: number, inputNodePath: NodePath) => boolean,
  isMatch?: (nodePath: NodePath) => boolean,
};

type Node = {
  id: number,
  path: NodePath,
  tag: GameNodeTag,
};

type NumberedLink = {
  in: number | string,
  out: number | string,
};

type Skeleton = {
  rootNodePath: UniqueNodePath,
  nodes: Array<Node>,
  numberedLinks: Array<NumberedLink>,
  deformations: SkeletonDeformProcessor,
};

type SpriteSheetsXMLBlueprint = {
  tag: "spritesheets",
  children?: Array<{
    tag: "spritesheet",
    attributes: {
      name: string,
      resolution: string,
      filename: string,
      width: number,
      height: number,
    },
    children: Array<{
      tag: "sprite",
      attributes: {
        name: SpritePath,
        rect: string,
        offsetX: number,
        offsetY: number,
        scaleX: number,
        scaleY: number,
        angleDegrees: number,
        skewDegrees: number,
      },
    }>
  }>
};

// When and for how long a sprite is shown
type KeyFrame = { spriteIdx: number, timelineFrame: number, exposure: number };

type Settings = {
  savingPath: string,
  savingName: string,
  useSceneMarkers: boolean,
  unitScalePreset: string,
  unitScale: number,
  maxWidth: number,
  maxHeight: number,
  resolutionType: "ANY" | "POT" | "NPOT",
  fixResolution: boolean,
  reuseFrames: boolean,
  reuseFramesThreshold: number,
  spriteResolutions: Record<string, { width: number, height: number }>,
  precalculateBezier: boolean,
  individualSprites: boolean,
  encodeToTBG: boolean,
  includeOverlayAndUnderlay: boolean,
  overwriteProject: boolean,
  clearTextureFolder: boolean,
  exportPalettes: Record<string, { exclude: boolean }>,
};

type UniqueNodePath = `#${string}-${NodePath}`;

type PathPoint = {
  lockedInTime: number
  x: number
  y: number
  z: number
  tension?: number
  continuity?: number
  bias?: number
};

type BezierPoint = {
  x: number,
  y: number,
  lx: number,
  ly: number,
  rx: number,
  ry: number,
  constSeg: boolean,
};

type LinearPoint = {
  x: number,
  y: number,
};

type Vector = { values: number[] };

type Stream = {
  type: "STREAM",
  valueAtIndex: number[],
};

type PivotPoint = { x: number, y: number, z: number, start: number };

type GameNodeTag = "noNode" | "bake" | "read" | "cutter" | "inverseCutter" | "matte" | "peg" | "bone" | "composite" | "kinematic" | "invalid" | "ignored";

type Curve = { type: "BEZIER", points: BezierPoint[] }
  | { type: "3DPATH", points: PathPoint[] }
  | { type: "LINEAR", points: LinearPoint[] }
  | { type: "PIVOT", points: PivotPoint[] };

type AttributeInfo = { path: string, constant: number }
  | { path: string, column: string, curve: Curve | Stream };

type ProcessedAttributeInfo = { path: string, constant: number }
  | { path: string, column: string, curve: Curve };

type SchemaMapping = {
  "string": string,
  "number": number,
  "boolean": boolean,
};

type Schema = { [key: string]: keyof SchemaMapping };

type FromSchema<T extends Schema> = { [key in keyof T]: SchemaMapping[T[key]] };

type Tester = FromSchema<{ width: "number" }>;