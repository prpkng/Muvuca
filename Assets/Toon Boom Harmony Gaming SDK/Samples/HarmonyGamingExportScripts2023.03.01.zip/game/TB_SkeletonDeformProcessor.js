/*
 * Copyright Toon Boom Animation Inc - 2022
 */

var PostProcess = require("./TB_PostProcess.js").PostProcess;
var NodeUtil = require("./TB_NodeUtil.js");
var ObjUtil = require("./TB_ObjUtil.js");
var Iter = require("./TB_Iter.js").Iter;

/**
 * @param {PostProcess} postProcess
 * @param {Link[]} links
 * @param {{ exportVersion: number }} settings
 */
function SkeletonDeformProcessor(postProcess, links, settings) {

  var boneLinks = links
    .filter(function (link) {
      var gameType = NodeUtil.getUniqueNodeGameTag(link.out.nodePath);
      return gameType == "bone" || gameType == "composite";
    });
  var deforms = collectDeforms();

  /**
   * Takes an existing array of links and links in generated deform structures where
   * the original roots are referenced, removes existing deform entries.
   * @param {Array<Link>} links
   * @returns {Array<Link>}
   */
  this.processLinks = function (links) {
    switch (settings.exportVersion)
    {
      default:
      case 2:
      case 3:
        return links;
      case 1:
        var nodePathToDeform = ObjUtil.fromEntries(new Iter(deforms)
          .flatMap(function (deform) {
            return ObjUtil
              .entries(deform.childPathToParentPath)
              .map(function (entry) {
                return {
                  key: entry.key,
                  value: deform,
                };
              })
          }));
        return new Iter(links)
          .flatMap(function (link) {
            if (nodePathToDeform[link["out"].nodePath] != null)
              return [];
            var isKinematic = NodeUtil.getUniqueNodeGameTag(link.out.nodePath) == "kinematic";
            var parentDeform = nodePathToDeform[link["in"]];
            if (parentDeform != null)
            {
              return deformToGeneratedLinks(parentDeform, link, { linkToRoot: !isKinematic });
            }
            else
            {
              return [{
                "in": link["in"],
                "out": {
                  nodePath: link["out"].nodePath,
                  tag: link["out"].tag,
                  inputPort: 0,
                }
              }];
            }
          });
    }
  }

  /**
   * Generate XMLBlueprints to describe both the deform rest positions
   * and the animations of the bones per-timeline-marker.
   * @returns {{ nodePath: NodePath, attr: AttributeInfo }[]}
   */
  this.toAttributes = function () {

    var fieldToAttributes = /**@type Array<{ field: keyof BoneEntry, attribute: string }>*/([
      { field: "offsetX", attribute: "offset.x" },
      { field: "offsetY", attribute: "offset.y" },
      { field: "length", attribute: "length" },
      { field: "radius", attribute: "radius" },
      { field: "orientation", attribute: "rotation.z" }
    ]);

    var nodeToDeformInfo = new Iter(deforms)
      .flatMap(function (deform) {
        return ObjUtil.entries(processDeform(deform.rootPath, deform.childPathToParentPath));
      })
    return new Iter(nodeToDeformInfo)
      .flatMap(function (deformInfo) {
        return fieldToAttributes
          .map(function (fieldToAttribute) {
            return {
              nodePath: NodeUtil.decomposeUniqueNode(deformInfo.key).nodePath,
              attr: /**@type AttributeInfo*/({
                path: ["rest", fieldToAttribute.attribute].join("."),
                constant: deformInfo.value.rest[fieldToAttribute.field],
              }),
            };
          })
          .concat(fieldToAttributes
            .map(function (fieldToAttribute) {
              var attrPath = ["deform", fieldToAttribute.attribute].join(".");
              var nodePath = NodeUtil.decomposeUniqueNode(deformInfo.key).nodePath;
              return {
                nodePath: nodePath,
                attr: {
                  path: attrPath,
                  column: postProcess.deformColumnName(nodePath, attrPath),
                  curve: {
                    type: "LINEAR",
                    points: deformInfo.value.deforms.map(function (deformEntry, index) {
                      return {
                        x: index + 1,
                        y: deformEntry[fieldToAttribute.field],
                      };
                    }),
                  },
                },
              };
            }));
      });
  }

  function collectDeforms() {
    var deformsBones = boneLinks
      .map(function (link) { return [link.out.nodePath]; });
    var linkLookup = ObjUtil.fromEntries(boneLinks.map(function (link) {
      return { key: link.out.nodePath, value: link["in"] }
    }));
    var maxIterations = 100;
    var iteration = 0;
    do
    {
      var newDeformBones = /**@type Array<UniqueNodePath[]>*/([]);
      var alreadyCombined = /**@type Record<number, boolean>*/({});
      for (var deformIndex = 0; deformIndex < deformsBones.length; deformIndex++)
      {
        if (alreadyCombined[deformIndex])
        {
          continue;
        }
        var parentIndex = new Iter(deformsBones)
          .findIndex(function (potentialParentDeformation, otherIndex) {
            if (deformIndex == otherIndex) return false;
            return deformsBones[deformIndex]
              .some(function (bonePath) {
                var parentPath = linkLookup[bonePath];
                return potentialParentDeformation
                  .indexOf(parentPath) >= 0
              });
          });
        if (parentIndex == null || alreadyCombined[parentIndex])
        {
          newDeformBones.push(deformsBones[deformIndex]);
        }
        else
        {
          var parentDeformBones = deformsBones[parentIndex];
          newDeformBones = newDeformBones.filter(function (deformBones) { return deformBones != parentDeformBones });
          newDeformBones.push(deformsBones[parentIndex]
            .concat(deformsBones[deformIndex]));
          alreadyCombined[deformIndex] = true;
          alreadyCombined[parentIndex] = true;
        }
      };
      deformsBones = newDeformBones
    } while (ObjUtil.keys(alreadyCombined).length > 0 && ++iteration < maxIterations);

    var compositePaths = links
      .map(function (link) { return link.out.nodePath; })
      .filter(function (nodePath) { return NodeUtil.getUniqueNodeGameTag(nodePath) == "composite" })
    return deformsBones.map(function (deformBones) {
      var rootPath = deformBones[0];
      var childPathToParentPath = ObjUtil.fromEntries(deformBones
        .map(function (nodePath) { return { key: nodePath, value: linkLookup[nodePath] }; }))
      var compositeToBonePaths = ObjUtil.fromEntries(compositePaths
        .filter(function (compPath) {
          var parentPath = linkLookup[compPath];
          return deformBones.indexOf(parentPath) >= 0;
        })
        .map(function (compPath) {
          var nodePath = NodeUtil.decomposeUniqueNode(compPath).nodePath;
          var inputs = /**@type UniqueNodePath[]*/([]);
          for (var i = 0; i < node.numberOfInputPorts(nodePath); i++)
          {
            var inputPath = node.srcNode(nodePath, i);
            var aliasedInputIndex = new Iter(deformBones).findIndex(function (bonePath) {
              return NodeUtil.decomposeUniqueNode(bonePath).nodePath == inputPath;
            });
            if (aliasedInputIndex == null) continue;
            inputs.push(deformBones[aliasedInputIndex]);
          }
          return {
            key: compPath,
            value: inputs,
          };
        }));
      return {
        rootPath: rootPath,
        parentPath: linkLookup[rootPath],
        childPathToParentPath: childPathToParentPath,
        compositeToBonePaths: compositeToBonePaths,
      };
    });
  }

  /**
   * @param {number} uid
   * @param {UniqueNodePath} uniquePath
   */
  function cloneUniquePath(uid, uniquePath) {
    var decomp = NodeUtil.decomposeUniqueNode(uniquePath);
    return NodeUtil.uniqueNodePath(uid + "." + decomp.uid, decomp.nodePath);
  }

  // var existingSyntheticDeformStructures =  /**@type Lookup<UniqueNodePath, Link[]>*/({});
  var nextDeformID = 0;

  /**
  * @param {typeof deforms[number]} deform
  * @param {Link} link
  * @param {{ linkToRoot?: boolean }} props
  */
  function deformToGeneratedLinks(deform, link, props) {

    var deformID = nextDeformID++;

    /**
     * @param {UniqueNodePath} connectPath
     * @param {Link[]} startingLinks
     */
    function createInner(connectPath, startingLinks) {
      var finalLink = {
        "in": connectPath,
        "out": {
          nodePath: link["out"].nodePath,
          tag: link["out"].tag,
          inputPort: 0,
        }
      };
      var newLinks = [finalLink];
      var alreadyMentioned = /**@type Lookup<UniqueNodePath, true>*/({});
      var nodesToProcess = deform.compositeToBonePaths[link["in"]] || [link["in"]];
      var nodePath;
      while (nodePath = nodesToProcess.shift())
      {
        var parentPath = deform.childPathToParentPath[nodePath];
        if (nodePath != deform.rootPath)
        {
          nodesToProcess.push(parentPath);
        }
        if (alreadyMentioned[nodePath])
        {
          continue;
        }
        alreadyMentioned[nodePath] = true;
        newLinks.unshift({
          "in": nodePath == deform.rootPath
            ? startingLinks.length > 0
              ? startingLinks[startingLinks.length - 1].out.nodePath
              : parentPath
            : cloneUniquePath(deformID, parentPath),
          "out": {
            nodePath: cloneUniquePath(deformID, nodePath),
            tag: NodeUtil.getUniqueNodeGameTag(nodePath),
            inputPort: 0,
          },
        });
      }
      var newStructure = startingLinks.concat(newLinks);
      return newStructure;
    }

    if (!props.linkToRoot)
    {
      return createInner(cloneUniquePath(deformID, link["in"]), [])
    }
    else
    {
      var deformPath = cloneUniquePath(deformID, /**@type UniqueNodePath*/(link["in"] + "-DEFORM"));
      var deformRootPath = /**@type UniqueNodePath*/(deformPath + "-ROOT");
      return createInner(deformPath, [{
        "in": deform.parentPath,
        "out": {
          nodePath: deformPath,
          tag: /**@type GameNodeTag*/("deform"),
          inputPort: 0,
        },
      }, {
        "in": deformPath,
        "out": {
          nodePath: deformRootPath,
          tag: /**@type GameNodeTag*/("deformRoot"),
          inputPort: 0,
        },
      }])
    }
  }


  /**
   * @param {UniqueNodePath} rootPath
   * @param {Record<UniqueNodePath, UniqueNodePath>} childPathToParentPath
   * @typedef {{
   *   offsetX: number,
   *   offsetY: number,
   *   length: number,
   *   orientation: number,
   *   radius: number,
   * }} BoneEntry
   */
  function processDeform(rootPath, childPathToParentPath) {

    /**
     * @typedef {Array<{
     *    nodePath: UniqueNodePath,
     *    offset: { x: number, y: number },
     *    orientation: number,
     *    radius: number,
     *    length: number,
     *  }>} ProcessBoneEntries
     * @typedef {{ key: UniqueNodePath, value: BoneEntry }[]} ProcessBoneResult
     */

    /**
     * Process V1 of bone export is concerned with hiding the concept of radius from the renderer.
     * @param {ProcessBoneEntries} boneParamsEntries
     * @returns {ProcessBoneResult}
     */
    function processForBoneParamsV1(boneParamsEntries) {

      // Register child radius with parent for later lookup.
      var childRadiusLookup = ObjUtil.fromEntries(boneParamsEntries
        .map(function (entry) {
          var parentPath = childPathToParentPath[entry.nodePath];
          if (parentPath == null)
            return null;
          return {
            key: parentPath,
            value: entry.radius,
          };
        })
        .filter(Iter.notNull));

      return boneParamsEntries
        .map(function (entry) {

          // Change length to exclude radius area.
          var length = entry.length;
          var childRadius = childRadiusLookup[entry.nodePath];
          if (entry.nodePath != rootPath)
            length -= entry.radius;
          if (childRadius != null)
            length -= childRadius;
          length = Math.max(length, 1 / 32);

          // Offset starting point away from radius.
          var offset = entry.offset;
          var vector = {
            x: Math.cos(entry.orientation * 3.14159 / 180),
            y: Math.sin(entry.orientation * 3.14159 / 180),
          };
          if (entry.nodePath != rootPath)
          {
            offset.x += (1 + vector.x) * entry.radius;
            offset.y += vector.y * entry.radius * postProcess.xScale;
          }

          return {
            key: entry.nodePath,
            value: {
              offsetX: offset.x,
              offsetY: offset.y,
              length: length,
              radius: 0,
              orientation: entry.nodePath != rootPath ? entry.orientation : Math.atan2(
                vector.y,
                vector.x * postProcess.xScale) * 180 / 3.14159,
            },
          };
        });
    }

    /**
     * Process V2 of bone export provides renderer with radius data directly.
     * @param {ProcessBoneEntries} boneParamsEntries
     * @returns {ProcessBoneResult}
     */
    function processForBoneParamsV2(boneParamsEntries) {

      return boneParamsEntries
        .map(function (entry) {
          return {
            key: entry.nodePath,
            value: {
              offsetX: entry.offset.x,
              offsetY: entry.offset.y,
              length: entry.length,
              radius: entry.radius,
              orientation: entry.nodePath != rootPath ? entry.orientation : Math.atan2(
                Math.sin(entry.orientation * 3.14159 / 180),
                Math.cos(entry.orientation * 3.14159 / 180) * postProcess.xScale) * 180 / 3.14159,
            },
          };
        });
    }

    var processForBoneParams = settings.exportVersion == 1
      ? processForBoneParamsV1
      : processForBoneParamsV2;

    var childToParentEntries = ObjUtil.entries(childPathToParentPath);

    var boneParamsRestEntries = processForBoneParams(childToParentEntries
      .map(function (entry) {
        var nodePath = NodeUtil.decomposeUniqueNode(entry.key).nodePath;
        return {
          nodePath: entry.key,
          orientation: parseFloat(node.getTextAttr(nodePath, 1, "restOrientation")),
          radius: parseFloat(node.getTextAttr(nodePath, 1, "restRadius")),
          length: parseFloat(node.getTextAttr(nodePath, 1, "restLength")),
          offset: {
            x: parseFloat(node.getTextAttr(nodePath, 1, "restOffset.x")),
            y: parseFloat(node.getTextAttr(nodePath, 1, "restOffset.y")),
          },
        };
      }));

    var nodePathToDeformData = ObjUtil.fromEntries(boneParamsRestEntries.map(function (entry) {
      return {
        key: entry.key,
        value: {
          rest: entry.value,
          deforms: /**@type Array<ReturnType<typeof processForBoneParamsV1>[number]["value"]>*/([])
        }
      }
    }));

    for (var timelineFrame = 1; timelineFrame <= frame.numberOf(); timelineFrame++)
    {
      var boneParamsEntries = childToParentEntries
        .map(function (entry) {
          var nodePath = NodeUtil.decomposeUniqueNode(entry.key).nodePath;
          return {
            nodePath: entry.key,
            orientation: parseFloat(node.getTextAttr(nodePath, timelineFrame, "orientation")),
            radius: parseFloat(node.getTextAttr(nodePath, timelineFrame, "radius")),
            length: parseFloat(node.getTextAttr(nodePath, timelineFrame, "length")),
            offset: {
              x: parseFloat(node.getTextAttr(nodePath, timelineFrame, "offset.x")),
              y: parseFloat(node.getTextAttr(nodePath, timelineFrame, "offset.y")),
            },
          };
        });

      processForBoneParams(boneParamsEntries)
        .forEach(function (processResult) {
          nodePathToDeformData[processResult.key].deforms.push(processResult.value)
        });
    }

    return nodePathToDeformData;
  }
}

exports.SkeletonDeformProcessor = SkeletonDeformProcessor