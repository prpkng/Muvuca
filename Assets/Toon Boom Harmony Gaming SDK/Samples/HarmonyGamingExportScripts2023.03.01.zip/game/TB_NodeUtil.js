/*
 * Copyright Toon Boom Animation Inc - 2022
 */

var ObjUtil = require("./TB_ObjUtil.js");
var Iter = require("./TB_Iter.js").Iter;

/**
 * @param {NodePath} nodePath
 */
exports.nodePath = function (nodePath) {
  return nodePath.split("/").slice(1).join("_");
}

/**
* @param {NodePath} nodePath
*/
exports.nodePathToPivot = function (nodePath) {
  return exports.nodePath(nodePath) + "_Pivot";
}

exports.findTopNodes = function () {
  var writePath = exports.findFirstWriteNode();
  if (writePath == null)
    return [];
  return new exports.InputScan(writePath, {
    shouldEnterGroupNode: function () { return false; },
    isMatch: function (nodePath) {
      for (var i = 0; i < node.numberOfInputPorts(nodePath); i++)
      {
        var parent = node.srcNode(nodePath, i);
        if (parent != null && parent.length > 0)
          return false;
      }
      return exports.getNodeGameTag(nodePath) != "ignored";
    }
  }).toArray();
}

/**
 * Starting from a node path, search upwards through node graph inputs, collecting nodes that match criteria
 * @param {NodePath} outputPath
 * @param {{
 *    shouldEnterGroupNode?: (nodePath: NodePath) => boolean,
 *    isMatch?: (nodePath: NodePath) => boolean,
 *    shouldQuitBranch?: (nodePath: NodePath, inputPort: number) => boolean,
 * }=} callbacks
 */
exports.InputScan = function (outputPath, callbacks) {
  /** @type {Record<NodePath, boolean>} */
  var resultNodeLookup = {};
  var unparsedNodes = [outputPath];
  var nodePath;
  while (nodePath = unparsedNodes.pop())
  {
    for (var i = 0; i < node.numberOfInputPorts(nodePath); i++)
    {
      var inputNodePath = node.srcNode(nodePath, i);
      if (callbacks == null
        || callbacks.shouldEnterGroupNode == null
        || callbacks.shouldEnterGroupNode(inputNodePath))
      {
        inputNodePath = node.flatSrcNode(nodePath, i);
      }
      if (inputNodePath == node.noNode()) continue;
      if (callbacks == null
        || callbacks.shouldQuitBranch == null
        || !callbacks.shouldQuitBranch(nodePath, i))
      {
        unparsedNodes.unshift(inputNodePath);
      }
    }
    if (callbacks == null
      || callbacks.isMatch == null
      || callbacks.isMatch(nodePath))
      resultNodeLookup[nodePath] = true;
  }

  this.toLookup = function () {
    return resultNodeLookup;
  }

  this.toArray = function () {
    return ObjUtil.keys(resultNodeLookup);
  }
}

/**
 * Starting from a node path, search downwards through node graph outputs, collecting nodes that match criteria
 * @param {NodePath} inputPath
 * @param {{
 *    shouldEnterGroupNode?: ((nodePath: NodePath) => boolean);
 *    isMatch?: (nodePath: NodePath) => boolean;
 * }} [callbacks]
 */
exports.OutputScan = function (inputPath, callbacks) {
  /**@type {Record<NodePath, boolean>}*/
  var resultNodeLookup = {};
  var unparsedNodes = [inputPath];
  var nodePath;
  while (nodePath = unparsedNodes.pop())
  {
    var outputPorts = node.numberOfOutputPorts(nodePath);
    for (var outputPort = 0; outputPort < outputPorts; outputPort++)
    {
      var outputLinks = node.numberOfOutputLinks(nodePath, outputPort);
      for (var outputLink = 0; outputLink < outputLinks; outputLink++)
      {
        var outputNodePath = node.dstNode(nodePath, outputPort, outputLink);
        while (node.isGroup(outputNodePath)
          && (callbacks == null
            || callbacks.shouldEnterGroupNode == null
            || callbacks.shouldEnterGroupNode(outputNodePath)
          ))
        {
          outputNodePath = /**@type NodePath*/(outputNodePath + "/Multi-Port-In");
        }
        if (outputNodePath == node.noNode()) continue;
        if (node.type(outputNodePath) == "MULTIPORT_OUT")
        {
          outputNodePath = node.parentNode(outputNodePath);
        }
        unparsedNodes.unshift(outputNodePath);
      }
    }
    if (callbacks == null || callbacks.isMatch == null || callbacks.isMatch(nodePath))
    {
      resultNodeLookup[nodePath] = true;
    }
  }
  this.toLookup = function () {
    return resultNodeLookup;
  }
  this.toArray = function () {
    return ObjUtil.keys(resultNodeLookup);
  }
}

/**
 * @param {UniqueNodePath} uniqueNodePath
 */
exports.decomposeUniqueNode = function (uniqueNodePath) {
  var dashSplit = uniqueNodePath.split("-");
  return {
    uid: dashSplit[0].slice(1),
    nodePath: /**@type NodePath*/(dashSplit.slice(1).join("-")),
  };
}

/**
 * @param {string} uid
 * @param {NodePath} nodePath
 */
exports.uniqueNodePath = function (uid, nodePath) {
  return /**@type UniqueNodePath*/("#" + uid + "-" + nodePath);
}

exports.bakePrefix = "bake_";

var nodeCategories = {
  read: ["READ"],
  cutter: ["CUTTER", "CUTTER-MASK"],
  peg: ["PEG"],
  kinematic: ["KinematicOutputModule"],
  bone: ["BendyBoneModule", "GameBoneModule"],
  ignored: ["COMPOSITE", "DeformationCompositeModule", "WRITE", "DISPLAY", "COLOR_CARD"],
};

/**
 * @param {NodePath} nodePath
 * @returns {GameNodeTag}
 */
exports.getNodeGameTag = function (nodePath) {
  if (nodePath == node.noNode()) return "noNode";
  if (node.isGroup(nodePath) && (node.getName(nodePath).substring(0, exports.bakePrefix.length) == exports.bakePrefix))
    return "bake";
  var categoryKeys = ObjUtil.keys(nodeCategories);
  var nodeType = node.type(nodePath);
  if (nodeType == "CUTTER" && node.getTextAttr(nodePath, 1.0, "inverted") == "Y")
  {
    return "inverseCutter";
  }
  for (var i = 0; i < categoryKeys.length; i++)
  {
    var categoryKey = categoryKeys[i];
    if (nodeCategories[categoryKey].indexOf(nodeType) >= 0) return categoryKey;
  }
  return "invalid";
}

/**
 * @param {UniqueNodePath} nodePath
 * @returns {GameNodeTag}
 */
exports.getUniqueNodeGameTag = function (nodePath) {
  return exports.getNodeGameTag(exports.decomposeUniqueNode(nodePath).nodePath);
}

/**
 * @param {NodePath} nodePath
 */
exports.getNodeInfo = function (nodePath) {
  return {
    path: nodePath,
    type: node.type(nodePath),
    category: exports.getNodeGameTag(nodePath),
  }
}

exports.findFirstWriteNode = function () {
  return exports.findFirstNodeOfType("WRITE", node.root());
}

exports.findFirstDisplayNode = function () {
  return exports.findFirstNodeOfType("DISPLAY", node.root());
}

/**
 * @param {"WRITE" | "DISPLAY"} type
 * @param {NodePath} layerPath
 * @returns {NodePath | undefined}
 */
exports.findFirstNodeOfType = function (type, layerPath) {
  var groups = /**@type {NodePath[]}*/([]);
  for (var i = 0; i < node.numberOfSubNodes(layerPath); ++i)
  {
    var nodePath = node.subNode(layerPath, i);
    if (node.type(nodePath) == type)
    {
      return nodePath;
    }
    if (node.isGroup(nodePath))
    {
      groups.push(nodePath);
    }
  }
  for (var i = 0; i < groups.length; ++i)
  {
    var result = exports.findFirstNodeOfType(type, groups[i]);
    if (result != null)
      return result;
  }
}

/**
 * Build pathChain - taking each first input up towards the root node, describes all alternative paths up the chain.
 * @param {ChainSource} chainSource
 * @param {LinkGeneratorCallbacks} callbacks
 * @returns {{
 *    pathChain: PathChain
 *    deferredChainSources: ChainSource[],
 * }}
 */
function buildPathChain(chainSource, callbacks) {
  var input = chainSource.input;
  /**@type {ChainSource[]}*/
  var deferredChainSources = [];
  var pathChain = chainSource.ancestorInputs
    .map(function (input) {
      return { input: input, siblingInputs:  /**@type Array<InputToNode>*/([]) };
    });
  while (input != null)
  {
    var inputNodePaths = /**@type Array<InputToNode>*/([]);
    var inputPorts = node.numberOfInputPorts(input.nodePath);
    for (var inputPort = inputPorts - 1; inputPort >= 0; inputPort--)
    {
      var isMatch = callbacks == null || callbacks.isMatch == null || callbacks.isMatch(input.nodePath);
      var nextInput = {
        nodePath: node.srcNode(input.nodePath, inputPort),
        inputPort: isMatch ? inputPort : input.inputPort,
      };
      if (callbacks != null
        && callbacks.shouldDeferInputToSeperateChain != null
        && callbacks.shouldDeferInputToSeperateChain(input.nodePath, inputPort, nextInput.nodePath))
      {
        var newDefferedChainSource = {
          input: nextInput,
          ancestorInputs: pathChain
            .filter(function (link) { return callbacks.isMatch == null || callbacks.isMatch(link.input.nodePath) })
            .map(function (link) { return link.input; })
            .concat(input),
        };
        deferredChainSources.push(newDefferedChainSource);
        continue;
      }
      if (callbacks == null
        || callbacks.shouldEnterGroupNode == null
        || callbacks.shouldEnterGroupNode(nextInput.nodePath))
      {
        nextInput = {
          nodePath: node.flatSrcNode(input.nodePath, inputPort),
          inputPort: isMatch ? inputPort : input.inputPort,
        };
      }
      if (nextInput.nodePath == node.noNode())
        continue;
      inputNodePaths.push(nextInput);
    }
    pathChain.push({ input: input, siblingInputs: inputNodePaths.slice(1) });
    input = inputNodePaths.length == 0 ? null : inputNodePaths[0];
  }
  return {
    pathChain: pathChain,
    deferredChainSources: deferredChainSources,
  };
}

/**
 * @param {UniqueNodePath} nodePath
 * @param {UniqueNodePath} parentNodePath
 */
function uniqueLink(nodePath, parentNodePath) {
  return /**@type UniqueLink*/(parentNodePath + " -> " + nodePath);
}

/**
 * @param {PathChain} pathChain
 * @param {Lookup<NodePath, UniqueNodePath>} nodePathToUnique
 * @param {Lookup<UniqueLink, true?>} uniqueLinks
 * @param {number} chainIdx
 */
function pathChainToUniqueLinks(pathChain, chainIdx, nodePathToUnique, uniqueLinks) {
  var nextNodePathToUnique = /**@type Lookup<NodePath, UniqueNodePath>**/({})
  return {
    uniqueLinks: pathChain
      .reverse()
      .map(function (link, linkIndex) {

        var parentInput = linkIndex == 0 ? null : pathChain[linkIndex - 1].input;
        var parentPath = parentInput == null ? /**@type NodePath*/("Top") : parentInput.nodePath;
        var uniqueNodePath = nodePathToUnique[link.input.nodePath] || exports.uniqueNodePath("" + chainIdx, link.input.nodePath);
        var uniqueParentPath = (parentPath == /**@type NodePath*/("Top") ? /**@type UniqueNodePath*/("Top") : nodePathToUnique[parentPath])
          || exports.uniqueNodePath("" + chainIdx, parentPath);

        nextNodePathToUnique[link.input.nodePath] = uniqueNodePath;
        nextNodePathToUnique[parentPath] = uniqueParentPath;

        var uniqueLinkCandidate = uniqueLink(uniqueNodePath, uniqueParentPath);
        if (uniqueLinks[uniqueLinkCandidate])
          return null;
        else
          uniqueLinks[uniqueLinkCandidate] = true;

        return {
          "in": uniqueParentPath,
          "out": {
            tag: exports.getNodeGameTag(link.input.nodePath),
            nodePath: uniqueNodePath,
            inputPort: parentInput == null ? 0 : parentInput.inputPort,
          }
        };
      })
      .filter(Iter.notNull),
    nextNodePathToUnique: nextNodePathToUnique,
  }
}

/**
 * Discover additional chain sources to add throughout the current pathChain.
 * @param {PathChain} pathChain
 * @param {LinkGeneratorCallbacks} callbacks
 * @returns {ChainSource[]}
 */
function pathChainToAdditionalSources(pathChain, callbacks) {
  return new Iter(pathChain)
    .flatMap(function (link, linkIndex) {
      return link.siblingInputs
        .map(function (inputNodePath) {
          return {
            input: inputNodePath,
            ancestorInputs: pathChain.slice(0, linkIndex + 1)
              .filter(function (link) { return callbacks.isMatch == null || callbacks.isMatch(link.input.nodePath) })
              .map(function (link) { return link.input; })
          };
        })
        .reverse();
    })
}

/**
 * Special node parsing procedure for gathering skeleton nodes.
 * Parsing is done in 'chains' from the source to the root.
 * Chains that 'cross-over' require duplicate nodes so that final structure has no crossing links (required for composite ordering).
 * Doing so requires the introduction of "UniqueNodePath"s for use as keys in later Hashmap lookups.
 * @param {NodePath} outputPath
 * @param {LinkGeneratorCallbacks} callbacks
 * @param {{uncross: boolean}} options
 */
exports.generateRenderSortedLinks = function (outputPath, callbacks, options) {
  /**@type {Link[]}*/
  var resultLinks = [];
  /**@type {Array<ChainSource>}*/
  var chainSources = [{ input: { nodePath: outputPath, inputPort: 0 }, ancestorInputs: [] }]
  var chainSource;
  /**@type {Array<ChainSource>}*/
  var deferredChainSources = [];
  /**@type Lookup<NodePath, UniqueNodePath>*/
  var currentNodePathLookup = {};
  /**@type Lookup<UniqueLink, true?>*/
  var uniqueLinks = {};
  var chainIdx = 0;
  var infiniteLoopCounter = 0;
  while (chainSources.length > 0)
  {
    if (infiniteLoopCounter++ > 10)
      throw new Error("Infinite loop detected");
    while (chainSource = chainSources.pop())
    {
      var pathChainResult = buildPathChain(chainSource, callbacks);
      var deferredChainSources = deferredChainSources.concat(pathChainResult.deferredChainSources);
      var additionalSources = pathChainToAdditionalSources(pathChainResult.pathChain, callbacks);
      chainSources = chainSources.concat(additionalSources);
      var validPathChain = pathChainResult.pathChain
        .filter(function (link) { return callbacks.isMatch == null || callbacks.isMatch(link.input.nodePath) });
      var uniqueLinksResult = pathChainToUniqueLinks(validPathChain, chainIdx, currentNodePathLookup, uniqueLinks);
      currentNodePathLookup = options.uncross
        ? uniqueLinksResult.nextNodePathToUnique
        : ObjUtil.assign(currentNodePathLookup, uniqueLinksResult.nextNodePathToUnique);
      resultLinks = resultLinks.concat(uniqueLinksResult.uniqueLinks);
      chainIdx++;
    }
    chainSources = deferredChainSources;
  }

  return resultLinks;
}

/**@type Record<string, boolean>**/
var seperateAttributes = {
  "X": true,
  "Y": true,
  "Z": true,
}
/**@type Record<string, boolean>**/
var nonSeperateAttributes = {
  "XY": true,
  "XYZ": true,
}
var indexToSubattribute = ["X", "Y", "Z"];



/**
 * @param {NodePath} nodePath
 * @param {{ precalculateBezier?: boolean, attributeWhitelist?: Lookup<string, true>}} settings
 */
exports.findModifiedAttributesForNode = function (nodePath, settings) {
  // Get the pivot at every frame, this could change due to a child drawing having the "Apply Embedded Pivot on Parent Peg" setting enabled.
  var pivotAtFrame = []
  var previousPivot = /**@type Point3d | null*/(null);
  for (var i = 1; i <= frame.numberOf(); i++)
  {
    var pivot = node.getPivot(nodePath, i);
    if (previousPivot == null || pivot.x != previousPivot.x || pivot.y != previousPivot.y)
    {
      pivotAtFrame.push({ x: pivot.x, y: pivot.y, z: pivot.z, start: i });
      previousPivot = pivot;
    }
  }
  var modifiedAttributes = /**@type AttributeInfo[]*/([{ path: "PIVOT", column: exports.nodePathToPivot(nodePath), curve: { type: "PIVOT", points: pivotAtFrame } }]);
  var attributesToCheck = node.getAttrList(nodePath, 1)
    .map(function (attr) { return { attr: attr, path: "" } })
    .reverse();
  var candidate;
  while (candidate = attributesToCheck.pop())
  {
    try
    {
      var subAttributes = candidate.attr.getSubAttributes();
      var attrPath = candidate.path.length == 0
        ? candidate.attr.keyword()
        : candidate.path + "." + candidate.attr.keyword();
      if (subAttributes != null)
      {
        var seperateAttrIndex = new Iter(subAttributes)
          .findIndex(function (attr) { return attr.keyword() == "SEPARATE" });
        if (seperateAttrIndex != null)
        {
          var removeLookup = subAttributes[seperateAttrIndex].boolValue()
            ? nonSeperateAttributes
            : seperateAttributes;
          subAttributes = subAttributes
            .filter(function (attr) { return !removeLookup[attr.keyword()] });
        }
        subAttributes.forEach(function (attr) { attributesToCheck.unshift({ attr: attr, path: attrPath }) });
      }
      if (settings.attributeWhitelist != null && !settings.attributeWhitelist[attrPath])
      {
        continue;
      }
      var linkedColumn = node.linkedColumn(nodePath, attrPath);
      if (linkedColumn != null && linkedColumn.length > 0)
      {
        var curves = exports.parseColumnForCurves(nodePath, attrPath, linkedColumn, settings);
        if (curves.length == 1)
          modifiedAttributes.push({ path: attrPath, column: linkedColumn, curve: curves[0] });
        else
          curves.forEach(function (curve, index) {
            modifiedAttributes.push({
              path: attrPath + "." + indexToSubattribute[index],
              column: linkedColumn + "_" + indexToSubattribute[index],
              curve: curve
            });
          });
        continue;
      }
      var constantValue = parseFloat(node.getTextAttr(nodePath, 1, attrPath));
      if (!isNaN(constantValue) && constantValue != 0)
      {
        modifiedAttributes.push({ path: attrPath, constant: constantValue });
        continue;
      }
    }
    catch (e)
    {
      MessageLog.trace("Error finding modified attributes for " + nodePath + " - " + e);
    }
  }
  return modifiedAttributes;
}

/**
 * Provide a concise list of novel frames from multiple timelineToData arrays
 * @param {number[]} groupOfTimelineToData
 * @param {Array<(number | null)[] | undefined>} groupOfTimelineToDisplayData
 * @param {Array<{ timelineFrame: number, frameValues: (number | null)[] }>} uniqueFramesInfo
 */
exports.findUniqueFramesForDisplayData = function (groupOfTimelineToData, groupOfTimelineToDisplayData, uniqueFramesInfo) {
  var timelineToUniqueFrame = [];
  for (var timelineFrame = 0; timelineFrame < frame.numberOf(); timelineFrame++)
  {
    var currentFrameValues = groupOfTimelineToDisplayData
      .map(function (d) { return d == null ? null : d[timelineFrame] });
    if (currentFrameValues.every(function (d) { return d == null; }))
    {
      timelineToUniqueFrame.push(null);
      continue;
    }
    currentFrameValues.push(groupOfTimelineToData[timelineFrame]);
    var uniqueFrame = new Iter(uniqueFramesInfo)
      .findIndex(function (uniqueFrame) {
        return uniqueFrame.frameValues
          .every(function (uniqueValue, columnIndex) {
            var currentValue = currentFrameValues[columnIndex];
            return uniqueValue == currentValue;
          });
      });
    if (uniqueFrame == null)
    {
      uniqueFrame = uniqueFramesInfo.length;
      uniqueFramesInfo.push({ timelineFrame: timelineFrame, frameValues: currentFrameValues });
    };
    timelineToUniqueFrame.push(uniqueFrame);
  }
  return {
    timelineToUniqueFrame: timelineToUniqueFrame,
    uniqueFramesInfo: uniqueFramesInfo,
  };
}

/**
 * Provide a concise list of novel frames from multiple timelineToData arrays
 * @param {Array<number[]>} groupOfTimelineToData
 */
exports.findUniqueFramesForData = function (groupOfTimelineToData) {
  var uniqueFramesInfo = [];
  var timelineToUniqueFrame = [];
  for (var timelineFrame = 0; timelineFrame < frame.numberOf(); timelineFrame++)
  {
    var currentFrameValues = groupOfTimelineToData
      .map(function (d) { return d[timelineFrame] });
    var uniqueFrame = new Iter(uniqueFramesInfo)
      .findIndex(function (uniqueFrame) {
        return uniqueFrame.frameValues
          .every(function (uniqueValue, columnIndex) {
            var currentValue = currentFrameValues[columnIndex];
            return uniqueValue == currentValue;
          });
      });
    if (uniqueFrame == null)
    {
      uniqueFrame = uniqueFramesInfo.length;
      uniqueFramesInfo.push({ timelineFrame: timelineFrame, frameValues: currentFrameValues });
    };
    timelineToUniqueFrame.push(uniqueFrame);
  }
  return timelineToUniqueFrame;
}

/**
 * Retrieve values, either single, tuple or x/y/z
 * @param {NodePath} nodePath
 * @param {number} frame
 * @param {string} attrPath
 */
exports.getValuesFromAttrAtFrame = function (nodePath, frame, attrPath) {
  var rawText = node.getTextAttr(nodePath, frame, attrPath);
  var textValues;
  if (rawText.length == 0)
    textValues = ["X", "Y", "Z"].map(function (subAttr) {
      return node.getTextAttr(nodePath, frame, attrPath + "." + subAttr);
    })
  else
    textValues = rawText.split(" ");
  return textValues
    .map(parseFloat)
    .map(function (value) { return isNaN(value) ? 0 : value; });
}

/**
 * Get raw values from column for every frame as an array of streams
 * @param {NodePath} nodePath
 * @param {string} attrPath
 */
exports.retrieveRawColumnData = function (nodePath, attrPath) {
  var streams = exports.getValuesFromAttrAtFrame(nodePath, 1, attrPath).map(function () {
    return /**@type number[]*/([]);
  });
  for (var timelineFrame = 1; timelineFrame <= frame.numberOf(); timelineFrame++)
  {
    exports.getValuesFromAttrAtFrame(nodePath, timelineFrame, attrPath)
      .forEach(function (value, index) { streams[index].push(value); });
  }
  return streams.map(function (stream) { return { type: /**@type const*/("STREAM"), valueAtIndex: stream }; });
}

/**
 * Get list of points for column, disclose type of points returned
 * @param {NodePath} nodePath
 * @param {string} attrPath
 * @param {string} linkedColumn
 * @param {{ precalculateBezier?: boolean}} settings
 * @returns {Array<Curve | Stream>}
 */
exports.parseColumnForCurves = function (nodePath, attrPath, linkedColumn, settings) {
  if (settings.precalculateBezier)
  {
    return exports.retrieveRawColumnData(nodePath, attrPath);
  }
  var columnType = column.type(linkedColumn);
  switch (columnType)
  {
    case "BEZIER":
      var curve = exports.parseBezierForPoints(linkedColumn);
      if (curve.points.length == 0)
        return [{ type: "LINEAR", points: [{ x: 1, y: parseFloat(node.getTextAttr(nodePath, 1, attrPath)) }] }];
      return [curve];
    case "3DPATH":
      return exports.parse3DPathForPoints(linkedColumn)
        .filter(function (curve) { return curve.points.length > 0; });
  }
  return [];
}

/**
 * Trim curve to a start/end time, offsetting all temporal elements per-point to originate at the start time. Processes RawData channels into consecutive curves.
 * @param {Curve | Stream} curve
 * @param {number} startTime
 * @param {number} length
 * @returns {Curve}
 */
exports.trimAndOffsetCurve = function (curve, startTime, length) {
  var endTime = startTime + length;
  var timings = curve.type == "PIVOT" ? curve.points.map(function (pivotPoint) { return pivotPoint.start })
    : curve.type == "3DPATH" ? curve.points.map(function (point) { return point.lockedInTime; })
      : curve.type == "LINEAR" || curve.type == "BEZIER"
        ? curve.points.map(function (point) { return point.x; })
        : curve.valueAtIndex.map(function (_, index) { return index + 1 });
  var firstValidIndex = 0;
  var lastValidIndex = timings.length;
  for (var i = 0; i < timings.length - 1; i++)
  {
    if (timings[i] <= startTime && timings[i + 1] > startTime)
    {
      firstValidIndex = i;
    }
    if (timings[i] < endTime && timings[i + 1] >= endTime)
    {
      lastValidIndex = i + 1;
    }
  }
  return curve.type == "PIVOT"
    ? {
      type: curve.type,
      points: curve.points
        .filter(function (_, index) { return index >= firstValidIndex && index <= lastValidIndex; })
        .map(function (pivotPoint) {
          return {
            x: pivotPoint.x,
            y: pivotPoint.y,
            z: pivotPoint.z,
            start: pivotPoint.start - startTime + 1,
          };
        }),
    }
    : curve.type == "STREAM"
      ? {
        type: "LINEAR",
        points: curve.valueAtIndex
          .filter(function (_, index) { return index >= firstValidIndex && index <= lastValidIndex; })
          .map(function (value, index) {
            if (value == null)
            {
              return null;
            }
            return {
              x: index + 1,
              y: value,
            };
          })
          .filter(Iter.notNull),
      }
      : curve.type == "LINEAR"
        ? {
          type: curve.type,
          points: curve.points
            .filter(function (_, index) { return index >= firstValidIndex && index <= lastValidIndex; })
            .map(function (point) {
              return {
                x: point.x - startTime,
                y: point.y,
              };
            }),
        }
        : curve.type == "BEZIER"
          ? {
            type: curve.type,
            points: curve.points
              .filter(function (_, index) { return index >= firstValidIndex && index <= lastValidIndex; })
              .map(function (point) {
                return {
                  x: point.x - startTime,
                  y: point.y,
                  lx: point.lx - startTime,
                  ly: point.ly,
                  rx: point.rx - startTime,
                  ry: point.ry,
                  constSeg: point.constSeg,
                };
              }),
          }
          : {
            type: curve.type,
            points: curve.points
              .filter(function (_, index) { return index >= firstValidIndex && index <= lastValidIndex; })
              .map(function (point) {
                return {
                  lockedInTime: point.lockedInTime - startTime,
                  x: point.x,
                  y: point.y,
                  z: point.z,
                  tension: point.tension,
                  continuity: point.continuity,
                  bias: point.bias,
                };
              }),
          };
}

/**
 * @param {string} columnName
 * @returns {Curve & { type: "BEZIER"}}
 */
exports.parseBezierForPoints = function (columnName) {
  var result = [];
  var pointsLength = func.numberOfPoints(columnName);
  for (var i = 0; i < pointsLength; i++)
  {
    result.push({
      x: func.pointX(columnName, i),
      y: func.pointY(columnName, i),
      lx: func.pointHandleLeftX(columnName, i),
      ly: func.pointHandleLeftY(columnName, i),
      rx: func.pointHandleRightX(columnName, i),
      ry: func.pointHandleRightY(columnName, i),
      constSeg: func.pointConstSeg(columnName, i),
    });
  }
  return { type: "BEZIER", points: result };
}

/**
 * @param {string} columnName
 * @returns {Array<Curve & { type: "BEZIER"}>}
 */
exports.parse3DPathForPoints = function (columnName) {
  var separateColumns = func.convertToSeparate(columnName, "TRANSFORM_MATRIX");
  if (separateColumns == null)
    return [];
  var bezierPoints = separateColumns.map(exports.parseBezierForPoints);
  return bezierPoints;
}


/**
 * @template T
 * @param {{
 *  skinName: SkinName,
 *  nodePaths: NodePath[],
 *  timelineFrame: number,
 *  spriteIdxLookup: Record<NodePath, Lookup<SkinName, (number | null)[]>>,
 *  preRegisterUndo: boolean,
 * }} props 
 * @param { () => T } process
 * @retuns T
 */
exports.withTempSkinSwappedDrawingsAtFrame = function (props, process) {
  var undoChangeRegistered = props.preRegisterUndo;
  try
  {
    scene.beginUndoRedoAccum(translator.tr("Render Node"));

    props.nodePaths.forEach(function (nodePath) {
      var spriteIdxLookupAtPath = props.spriteIdxLookup[nodePath];
      var timelineToSpriteIdx = spriteIdxLookupAtPath[props.skinName];
      if (timelineToSpriteIdx == null) return;
      var newSpriteIdx = timelineToSpriteIdx[props.timelineFrame - 1];
      var columnName = node.linkedColumn(nodePath, "DRAWING.ELEMENT");
      var elementId = column.getElementIdOfDrawing(columnName);
      var newSprite = newSpriteIdx == null ? "" : Drawing.name(elementId, newSpriteIdx);
      var currentSprite = column.getEntry(columnName, 1, props.timelineFrame);
      if (currentSprite != newSprite)
      {
        column.setEntry(columnName, 1, props.timelineFrame, newSprite);
        undoChangeRegistered = true;
      }
    });

    return process();
  }
  finally
  {
    scene.endUndoRedoAccum();
    if (undoChangeRegistered)
    {
      scene.undo();
    }
  }
}
