/*
 * Copyright Toon Boom Animation Inc - 2022
 */

var PostProcess = require("./TB_PostProcess.js").PostProcess;
var SkeletonCutterProcessor = require("./TB_SkeletonCutterProcessor.js").SkeletonCutterProcessor;
var SkeletonDeformProcessor = require("./TB_SkeletonDeformProcessor.js").SkeletonDeformProcessor;
var NodeUtil = require("./TB_NodeUtil.js");
var ObjUtil = require("./TB_ObjUtil.js");
var XML = require("./TB_XMLBuilder.js");
var Iter = require("./TB_Iter.js").Iter;

/**
 * Export functions that deal in a fair amount of complexity, broken off from the main export process.
 * @param {{ unitScale: number, exportVersion: number, includeOverlayAndUnderlay: boolean }} settings
 */
exports.GameExportUtil = function (settings) {

  var postProcess = new PostProcess(settings.unitScale);

  var nextNodeID = 0;
  function nodeID() {
    return nextNodeID++;
  }

  /**
   * Generate a texture atlas.
   * API call is wrapped to elicit explicit settings names during calling.
   * @param {{
   *  textureFolder: string,
   *  rootFolder: string,
   *  resX: number,
   *  resY: number,
   *  maxSpriteSheet: number,
   *  riggingName: string,
   *  fixedResolution: boolean,
   *  resType: "POT" | "NPOT" | "ANY",
   *  spriteResName: string,
   *  reuseFramesThreshold: number,
   * }} settings
  */
  this.generateTextureAtlas = function (settings) {
    var message = GenerateTextureAtlas(
      settings.textureFolder,
      settings.rootFolder,
      settings.resX,
      settings.resY,
      settings.maxSpriteSheet,
      settings.riggingName,
      settings.fixedResolution,
      settings.resType,
      settings.spriteResName,
      settings.reuseFramesThreshold
    );
    if (message.length == 0) return /**@type const*/("success");
    return { error: message };
  }

  /**
   * Create skeleton. Care needs to be put into the order in which nodes are mentioned and linked,
   * as whatever nodes are referenced first are also rendered in-front of the later nodes.
   * So, the nodes have to be primarily ordered depth-first by where they appear in the skeleton hierarchy,
   * and secondarily what order they are referenced in composites from the bottom-up of the node graph.
   * @param {Link[]} links
   */
  this.buildSkeleton = function (links) {
    var processors = {
      cutters: new SkeletonCutterProcessor(settings),
      deformations: new SkeletonDeformProcessor(postProcess, links, settings),
    };
    ObjUtil.values(processors)
      .forEach(function (processor) {
        links = processor.processLinks(links);
      })
    var skeletonNodes = /**@type Record<UniqueNodePath, Node>*/({});
    links
      .forEach(function (link) {
        if (skeletonNodes[link.out.nodePath] != null)
        {
          return;
        }
        skeletonNodes[link.out.nodePath] = {
          tag: link.out.tag,
          id: nodeID(),
          path: NodeUtil.decomposeUniqueNode(link.out.nodePath).nodePath,
        };
      });

    var rootLink = links
      .filter(function (link) {
        return skeletonNodes[link["in"]] == null;
      })[0];
    var numberedLinks = links
      .map(function (link) {
        var inputNode = skeletonNodes[link["in"]];
        var outputNode = skeletonNodes[link["out"].nodePath];
        return {
          "in": inputNode != null ? inputNode.id : "Top",
          "out": outputNode.id,
          "port": link["out"].inputPort,
        };
      });
    /**@type {Skeleton}*/
    var skeleton = {
      rootNodePath: rootLink == null ? /**@type UniqueNodePath*/("Top") : rootLink.out.nodePath,
      nodes: ObjUtil.values(skeletonNodes),
      numberedLinks: numberedLinks,
      deformations: processors.deformations,
    };
    return skeleton;
  }

  /**
   * Special logic to prepare the render API for rendering the desired resolution
   * @param {{ width: number, height: number }} outputResolution
   */
  this.calculateRenderResolution = function (outputResolution) {
    var flipRes = (scene.currentResolutionY() > scene.currentResolutionX()) && (outputResolution.width > outputResolution.height);
    var aspectRatio = scene.currentResolutionY() / scene.currentResolutionX();
    return {
      width: Math.round(flipRes ? outputResolution.height : outputResolution.width),
      height: Math.round(outputResolution.width * aspectRatio),
    }
  }

  /**
   * Use Utransform script to generate .png file from a read node at a 'spriteIndex'
   * @param {{
   *  resolution: { width: number, height: number },
   *  nodePath: NodePath,
   *  spriteIndex: number,
   *  outputPath: string,
   * }} props
   * @returns {{
   *   originOffset: { x: number, y: number },
   *   scale: { x: number, y: number },
   *   croppedRect: { x: number, y: number, width: number, height: number},
   * } | null}
   */
  this.exportNode = function (props) {

    var columnName = node.linkedColumn(props.nodePath, "DRAWING.ELEMENT");
    var elementId = column.getElementIdOfDrawing(columnName);
    var spriteName = Drawing.name(elementId, props.spriteIndex);
    var sourceFilename = Drawing.filename(elementId, spriteName != null ? spriteName : props.spriteIndex + 1);

    // Non-tvg files can't be Utransformed, so we copy them to the output folder, and hope the rest works.
    var tvgSuffixCandidate = sourceFilename.slice(-4).toLowerCase();
    if (tvgSuffixCandidate != ".tvg")
    {
      MessageLog.trace("Copying non-tvg file " + sourceFilename + " to " + props.outputPath);
      var utransformResult = Utransform.apply(null, [
        "-outformat", "PNG4",
        "-outfile", props.outputPath, sourceFilename]);
      var resolution = CELIO.getInformation(props.outputPath);
      var scale = Math.min( // Harmony assumes that externally imported bmp/png files are sized to fullscreen scene assuming scene has a 4:3 aspect ratio. TODO: find source of this assumption.
        postProcess.unitScale * scene.numberOfUnitsY() / resolution.height,
        postProcess.unitScale * scene.numberOfUnitsY() * postProcess.xScale / resolution.width);
      return {
        originOffset: { x: 0, y: 0 },
        scale: { x: scale, y: scale },
        croppedRect: { x: 0, y: 0, width: resolution.width, height: resolution.height },
      };
    }

    var layersToRender = [
      { attr: "READ_LINE_ART", removeLayer: "-nolineart" },
      { attr: "READ_COLOR_ART", removeLayer: "-nocolorart" },
      { attr: "READ_OVERLAY_ART", addLayer: "-useoverlayart", usingOverlayUnderlay: true },
      { attr: "READ_UNDERLAY_ART", addLayer: "-useunderlayart", usingOverlayUnderlay: true }
    ]
      .filter(function (relation) { return settings.includeOverlayAndUnderlay || !relation.usingOverlayUnderlay; })
      .map(function (relation) {
        return node.getTextAttr(props.nodePath, 1, relation.attr) == "N"
          ? relation.removeLayer
          : relation.addLayer
      })
      .filter(Iter.notNull);

    var utransformResult = Utransform.apply(null, layersToRender.concat([
      "-resolution", "" + props.resolution.width, "" + props.resolution.height,
      "-antialiasing", "high", "1", // Setting could be disabled for index data in colors.
      "-outformat", "PNG4",
      "-crop",
      "-bgalpha", "0",
      "-outfile", props.outputPath, sourceFilename]));

    var utransformXML = XML.Blueprint.fromXMLString(utransformResult);
    if (utransformXML.attributes == null)
    {
      MessageLog.trace("Utransform failed to run for " + sourceFilename);
      MessageLog.trace("Outputted result: " + utransformResult);
      return null;
    }

    var centreOffsetX = /**@type number*/(utransformXML.attributes.centreOffsetX);
    var centreOffsetY = /**@type number*/(utransformXML.attributes.centreOffsetY);
    var resolutionX = /**@type number*/(utransformXML.attributes.cropResolutionX);
    var resolutionY = /**@type number*/(utransformXML.attributes.cropResolutionY);
    var scale = postProcess.unitScale * scene.numberOfUnitsY() / props.resolution.height;
    return {
      originOffset: { x: -centreOffsetX, y: -centreOffsetY },
      scale: { x: scale, y: scale },
      croppedRect: { x: 0, y: 0, width: resolutionX, height: resolutionY },
    };
  }

  /**
   * Render a zoomed out view of the scene to determine the bounds of the rendered area,
   * provide camera/render settings that frame that bounds.
   * @param {{  
   *   resolution: { width: number, height: number },
   *   timelineFrame: number,
   *   camera: NodePath
   * }} props
   */
  function calculateRenderSettings(props) {

    var framingResolution = 256;
    var zoomOutAmount = 2;

    var defaultFOV = 41.1121 * Math.PI / 180;
    var defaultCameraDistance = 12;
    var defaultCameraUnitHeight = 24;
    var pixelBorderWidth = {
      render: 2,
      utransform: 5,
    };
    var yDelta = Math.tan(defaultFOV / 2);
    var desiredFOV = Math.atan(yDelta * zoomOutAmount) * 180 / Math.PI * 2;

    node.setTextAttr(props.camera, "OFFSET.X", props.timelineFrame, "0");
    node.setTextAttr(props.camera, "OFFSET.Y", props.timelineFrame, "0");
    node.setTextAttr(props.camera, "OFFSET.Z", props.timelineFrame, "" + defaultCameraDistance);
    node.setTextAttr(props.camera, "OVERRIDE_SCENE_FOV", props.timelineFrame, "Y");
    node.setTextAttr(props.camera, "FOV", props.timelineFrame, "" + desiredFOV);

    render.setResolution(framingResolution, framingResolution);

    var allocatedRect = [0, 0, 0, 0];
    var getRenderBounds = function (/**@type number*/_, /**@type render.FrameCel*/frameCel) {
      allocatedRect = frameCel.allocatedRect();
    }
    render.frameReady.connect(getRenderBounds);
    render.renderScene(props.timelineFrame, props.timelineFrame);
    render.frameReady.disconnect(getRenderBounds);

    var imageCrop = {
      width: allocatedRect[2] - pixelBorderWidth.render * 2,
      height: allocatedRect[3] - pixelBorderWidth.render * 2,
      centerX: allocatedRect[0] + allocatedRect[2] / 2,
      centerY: framingResolution - (allocatedRect[1] + allocatedRect[3] / 2),
    }
    var renderScale = zoomOutAmount * props.resolution.height / framingResolution;
    var renderResolution = {
      width: imageCrop.width * renderScale + pixelBorderWidth.utransform * 2,
      height: imageCrop.height * renderScale + pixelBorderWidth.utransform * 2,
    }
    var defaultCameraRect = {
      height: framingResolution / zoomOutAmount,
      width: framingResolution / zoomOutAmount * postProcess.xScale,
      center: framingResolution / 2,
    };
    var zoom = renderResolution.height / renderScale / defaultCameraRect.height;
    var cameraSettings = {
      offsetX: (imageCrop.centerX - defaultCameraRect.center) * defaultCameraUnitHeight / defaultCameraRect.width,
      offsetY: (imageCrop.centerY - defaultCameraRect.center) * defaultCameraUnitHeight / defaultCameraRect.height,
      offsetZ: 12,
      fov: Math.atan(yDelta * zoom) * 180 / Math.PI * 2,
      zoom: zoom,
    };

    return {
      resolution: renderResolution,
      camera: cameraSettings,
    };
  }

  /**
   * @param {{
   *  spriteIdxLookup: Record<NodePath, Lookup<SkinName, Array<number | null>>>
   *  resolution: { width: number, height: number },
   *  nodePath: NodePath,
   *  skinName: SkinName,
   *  timelineFrame: number,
   *  outputPath: string,
   *  willUseCroppedRect: boolean,
   * }} props
   */
  this.bakeNode = function (props) {
    /**
     *  Drawing node element picker hack - Nodes must swap out their drawings to the requested skin at the rendered frame.
     */
    var nodesToDrawSwap = function () {
      if (node.type(props.nodePath) != "GROUP")
        return [props.nodePath];
      return node.subNodes(props.nodePath)
        .filter(function (nodePath) {
          return NodeUtil.getNodeGameTag(nodePath) == "read";
        });
    }();

    return NodeUtil.withTempSkinSwappedDrawingsAtFrame({
      nodePaths: nodesToDrawSwap,
      skinName: props.skinName,
      spriteIdxLookup: props.spriteIdxLookup,
      timelineFrame: props.timelineFrame,
      preRegisterUndo: true,
    }, function () {

      /**
       * Render node hack - Must ensure generated nodes are cleaned up
       */
      var parent = node.parentNode(props.nodePath);
      var coord = {
        x: node.coordX(props.nodePath),
        y: node.coordY(props.nodePath),
        z: node.coordZ(props.nodePath),
      };
      var temporaryDisplayName = "Temporary_Display";
      var temporaryDisplay = node.add(parent, temporaryDisplayName, "DISPLAY", coord.x + 50, coord.y + 80, coord.z + 1);
      node.unlink(props.nodePath, 0);

      var outputPorts = node.numberOfOutputPorts(props.nodePath);
      node.link(props.nodePath, outputPorts - 1, temporaryDisplay, 0);
      render.setAutoThumbnailCropping(false);
      render.setWhiteBackground(false);
      render.setRenderDisplay(temporaryDisplayName);

      var temporaryCameraName = "Temporary_Camera";
      var camera = node.add(parent, temporaryCameraName, "CAMERA", coord.x + 50, coord.y - 80, coord.z + 1);
      node.setAsDefaultCamera(temporaryCameraName);

      var renderSettings = calculateRenderSettings({
        resolution: props.resolution,
        timelineFrame: props.timelineFrame,
        camera: camera,
      });

      node.setTextAttr(camera, "OFFSET.X", props.timelineFrame, "" + renderSettings.camera.offsetX);
      node.setTextAttr(camera, "OFFSET.Y", props.timelineFrame, "" + renderSettings.camera.offsetY);
      node.setTextAttr(camera, "OFFSET.Z", props.timelineFrame, "" + renderSettings.camera.offsetZ);
      node.setTextAttr(camera, "FOV", props.timelineFrame, "" + renderSettings.camera.fov);
      render.setResolution(renderSettings.resolution.width, renderSettings.resolution.height);

      var originOffset = { x: 0, y: 0 };
      var scale = { x: 0, y: 0 };
      var croppedRect = [0, 0, 0, 0];
      var exportToPng = function (/**@type number*/_, /**@type render.FrameCel*/frameCel) {
        frameCel.imageFileAs(props.outputPath, "", "PNG4");
        croppedRect = frameCel.allocatedRect();
        originOffset = {
          x: renderSettings.camera.offsetX / renderSettings.camera.zoom / 24 * renderSettings.resolution.height * postProcess.xScale,
          y: renderSettings.camera.offsetY / renderSettings.camera.zoom / 24 * renderSettings.resolution.height,
        };
        scale = {
          x: postProcess.unitScale * scene.numberOfUnitsY() * renderSettings.camera.zoom / renderSettings.resolution.height,
          y: postProcess.unitScale * scene.numberOfUnitsY() * renderSettings.camera.zoom / renderSettings.resolution.height,
        };
        if (props.willUseCroppedRect)
        {
          var croppedCenter = {
            x: croppedRect[0] + croppedRect[2] / 2,
            y: renderSettings.resolution.height - (croppedRect[1] + croppedRect[3] / 2),
          };
          var cropOffset = {
            x: croppedCenter.x - renderSettings.resolution.width / 2,
            y: croppedCenter.y - renderSettings.resolution.height / 2,
          }
          originOffset.x += cropOffset.x;
          originOffset.y += cropOffset.y;
        }
      }
      render.frameReady.connect(exportToPng);
      render.renderScene(props.timelineFrame, props.timelineFrame);
      render.frameReady.disconnect(exportToPng);

      if (croppedRect[2] == 0 || croppedRect[3] == 0)
        return null;
      return {
        originOffset: originOffset,
        scale: scale,
        croppedRect: { x: croppedRect[0], y: croppedRect[1], width: croppedRect[2], height: croppedRect[3] },
      };
    });
  }


  /**
   * Take a mapping of timeline's frame index to a new sprite index and compress elements together
   * if they are the same, increasing exposure value while doing so.
   * @param {(number | null)[]} timelineToUniqueIdx
   */
  this.generateAnimationKeyframes = function (timelineToUniqueIdx) {
    var elements = [];
    var lastElement = /**@type KeyFrame | null*/(null);
    for (var timelineFrame = 0; timelineFrame < timelineToUniqueIdx.length; timelineFrame++)
    {
      var spriteIdx = timelineToUniqueIdx[timelineFrame];
      if (spriteIdx == null)
      {
        lastElement = null;
        continue;
      }
      else if (lastElement != null && lastElement.spriteIdx == spriteIdx)
      {
        lastElement.exposure++;
      }
      else
      {
        lastElement = { spriteIdx: spriteIdx, timelineFrame: timelineFrame + 1, exposure: 1 }
        elements.push(lastElement);
      }
    }
    return elements;
  }

  /**
   * @param {string} columnToCheck
   */
  function generateDrawingNameToIdx(columnToCheck) {
    var elementId = column.getElementIdOfDrawing(columnToCheck);
    var drawingNames = /**@type Record<string, number>*/({});
    if (elementId >= 0)
    {
      for (var i = 0; i < Drawing.numberOf(elementId); i++)
      {
        drawingNames[Drawing.name(elementId, i)] = i;
      }
    }
    return drawingNames;
  }

  this.generateDrawingNameToIdx = generateDrawingNameToIdx;

  /**
   * Gathers info about nodes:
   *  Given a node, skin and timelineFrame, what spriteIdx should be shown? (spriteIdxLookup).
   *  Given a node and spriteIdx, what timelineFrame and skin are needed to render it? (uniqueFrameLookup).
   * @param {RenderableNodePaths} renderableNodePaths List of paths to nodes organized by how it will be rendered
   * @param {NodePathToMeta} nodePathToMeta
   * @param {Lookup<SkinName, number>} skinToID
   * @param {Record<AnimationName, Marker>} animationToMarker
   * @returns {{
   *  spriteIdxLookup: Record<NodePath, Lookup<SkinName, Array<number | null>>>,
   *  uniqueFrameLookup: Record<NodePath, Array<null | { skinName: SkinName, timelineFrame: number }>>,
   * }} sprite information per-node
   */
  this.getDrawingDataForNodes = function (renderableNodePaths, nodePathToMeta, skinToID, animationToMarker) {

    /**
     * @param {NodePathToMeta[NodePath]} meta
     * @returns {Record<SkinName, (number | null)[] | undefined> | undefined}
     */
    var getUniqueTimelineFramesFromMeta = function (meta) {
      if (meta == null
        || meta.skinToAnimationToKeyframes == null)
        return;

      var entries = /**@type {{ key: SkinName, value: (number | null)[] }[]}*/([{ key: ("none"), value: [] }])
        .concat(ObjUtil.entries(meta.skinToAnimationToKeyframes)
          .map(function (skinEntry) {
            if (skinEntry.value == null)
            {
              return;
            }
            var skinName = skinEntry.key;
            if (skinName == "skin.Empty")
              return;
            var animationToKeyframes = skinEntry.value;
            /**@type Array<number | null>*/
            var timelineToUniqueFrame = [];
            ObjUtil.keys(animationToKeyframes)
              .forEach(function (animName) {
                var marker = animationToMarker[animName];
                if (marker == null) return;

                var i = marker.frame - 1;

                animationToKeyframes[animName]
                  .forEach(function (keyframe) {
                    var endFrame = i + keyframe.exposure;
                    for (; i <= endFrame; i++)
                    {
                      timelineToUniqueFrame[i] = keyframe.spriteIdx;
                    }
                  });
              });
            return {
              key: skinName,
              value: timelineToUniqueFrame,
            }
          })
          .filter(Iter.notNull));
      return ObjUtil.fromEntries(entries);
    }

    /**
     * @param {NodePath} nodePath
     */
    function generateUniqueDrawingEntry(nodePath) {
      var meta = nodePathToMeta[nodePath];
      // For nodes with metadata, gather timeline frames from metadata, remove mention of skin.Empty and make 'none' skin completely blank.
      var skinToTimelineToUniqueFrames = getUniqueTimelineFramesFromMeta(meta);
      if (skinToTimelineToUniqueFrames == null)
      {
        // Nodes without metadata have their 'none' skin set to whatever's on the timeline.
        var columnToCheck = node.linkedColumn(nodePath, "drawing.element");
        var unskinnedNodeTimeline = [];
        var drawingNames = generateDrawingNameToIdx(columnToCheck);
        for (var timelineFrame = 1; timelineFrame <= frame.numberOf(); timelineFrame++)
        {
          var spriteName = column.getEntry(columnToCheck, 1, timelineFrame);
          var spriteIdx = drawingNames[spriteName];
          unskinnedNodeTimeline.push(spriteIdx == null ? null : spriteIdx);
        }
        skinToTimelineToUniqueFrames = { "none": unskinnedNodeTimeline };
      }
      return {
        key: nodePath,
        value: skinToTimelineToUniqueFrames,
      };
    }

    /**
     * @param {NodePath} nodePath
     */
    function subNodesRecursive(nodePath) {
      var subNodes = node.subNodes(nodePath);
      return new Iter(subNodes).flatMap(/**@return {NodePath[]}*/function (subNode) {
        return subNodesRecursive(subNode);
      }).concat([nodePath]);
    }

    /**
     * Generate spriteIndexLookup: Each lookup value is a list associating timeline frames to unique sprite indices.
     */

    var spriteIdxLookupEntries = {
      read: renderableNodePaths.read
        .map(generateUniqueDrawingEntry)
        .filter(Iter.notNull),
      bake: renderableNodePaths.bake
        .map(function (groupNodePath) {
          var subNodes = subNodesRecursive(groupNodePath);
          var nonDrawingData = new Iter(subNodes)
            .flatMap(function (nodePath) {
              return NodeUtil.findModifiedAttributesForNode(nodePath, { precalculateBezier: true })
                .map(function (info) {
                  if (!("curve" in info) || info.curve.type != "STREAM")
                    return null;
                  return info.curve.valueAtIndex;
                })
                .filter(Iter.notNull);
            });
          var skinAgnosticFrames = NodeUtil.findUniqueFramesForData(nonDrawingData);
          var subNodeUniqueDrawingEntries = subNodes
            .map(generateUniqueDrawingEntry)
            .filter(Iter.notNull);
          var nextUniqueFramesInfo = /**@type {{ timelineFrame: number, frameValues: (number | null)[] }[]}*/([]);
          var skinToTimelineToUniqueFrames = ObjUtil.fromEntries(ObjUtil.keys(skinToID)
            .map(function (skinName) {
              var skinnedFramesForSkin = subNodeUniqueDrawingEntries
                .map(function (uniqueFrameEntry) { return uniqueFrameEntry.value[skinName] });
              if (skinnedFramesForSkin.length == 0)
                return null;
              var result = NodeUtil.findUniqueFramesForDisplayData(
                skinAgnosticFrames,
                skinnedFramesForSkin,
                nextUniqueFramesInfo);
              if (result.timelineToUniqueFrame.filter(Iter.notNull).length == 0)
                return null;
              nextUniqueFramesInfo = result.uniqueFramesInfo;
              return {
                key: skinName,
                value: result.timelineToUniqueFrame,
              };
            })
            .filter(Iter.notNull));
          return {
            subNodes: subNodes,
            bakeNodeEntry: {
              key: groupNodePath,
              value: skinToTimelineToUniqueFrames,
            },
          };
        }),
    };

    /**
     * Generate uniqueFrameLookup as a function of spriteIdxLookup, useful for rendering sprites (unique frames)
     */

    var uniqueFrameLookup = ObjUtil.fromEntries(
      spriteIdxLookupEntries.read
        .concat(spriteIdxLookupEntries.bake
          .map(function (elem) { return elem.bakeNodeEntry }))
        .map(function (nodeEntries) {
          var lookupFromNode = nodeEntries.value;
          /**@type Array<null | { skinName: SkinName, timelineFrame: number }>*/
          var uniqueFrames = [];
          ObjUtil.keys(lookupFromNode).forEach(function (skinName) {
            var lookupFromSkin = lookupFromNode[skinName];
            if (lookupFromSkin == null)
              return;
            lookupFromSkin.forEach(function (spriteIdx, timelineIdx) {
              if (spriteIdx == null)
                return;
              if (uniqueFrames[spriteIdx] == null)
                uniqueFrames[spriteIdx] = { skinName: skinName, timelineFrame: timelineIdx + 1 };
            });
          });
          return { key: nodeEntries.key, value: uniqueFrames };
        }));

    return {
      spriteIdxLookup: ObjUtil.fromEntries(
        spriteIdxLookupEntries.read
          .concat(new Iter(spriteIdxLookupEntries.bake)
            .flatMap(function (elem) {
              return elem.subNodes
                .map(generateUniqueDrawingEntry)
                .filter(Iter.notNull)
                .concat([elem.bakeNodeEntry])
            }))),
      uniqueFrameLookup: uniqueFrameLookup,
    }
  }

  /**
   * Retrieves all palettes from the scene
   * @param {Palette[]} palettes
   * @param {NodePath[]} visibleNodes
   * @returns Array of permutations, each entry lists the palette names
   * in the order that will provide a novel set of colors in output.
   */
  this.getPaletteVariations = function (palettes, visibleNodes) {

    var colorToNodePath = /**@type Record<string, NodePath[]>*/({});
    visibleNodes.forEach(function (nodePath) {
      var layerName = node.getTextAttr(nodePath, 1, "drawing.element.layer");
      var elementId = node.getElementId(nodePath);
      for (var drawingIdx = 0; drawingIdx < Drawing.numberOf(elementId); drawingIdx++)
      {
        var drawingId = Drawing.name(elementId, drawingIdx);
        var drawingKey = Drawing.Key({ elementId: elementId, layer: layerName, exposure: drawingId });
        DrawingTools.getDrawingUsedColors(drawingKey)
          .forEach(function (color) {
            var existingNodePaths = colorToNodePath[color];
            if (!existingNodePaths)
            {
              existingNodePaths = [];
              colorToNodePath[color] = existingNodePaths;
            }
            existingNodePaths.push(nodePath);
          });
      }
    });

    var paletteEntries = palettes
      .map(function (palette) {
        var colors = [];
        for (var colorIdx = 0; colorIdx < palette.nColors; colorIdx++)
        {
          colors.push(palette.getColorByIndex(colorIdx).id);
        }
        var nodePathsSet = /**@type Record<NodePath, boolean>*/({});
        colors.forEach(function (color) {
          var nodePaths = colorToNodePath[color];
          if (nodePaths == null)
            return;
          nodePaths.forEach(function (nodePath) {
            nodePathsSet[nodePath] = true;
          });
        });
        var nodePaths = ObjUtil.keys(nodePathsSet);
        if (nodePaths.length == 0)
          return null;
        return {
          palette: processPalette(palette),
          nodePaths: nodePaths,
        };
      })
      .filter(Iter.notNull);
    var allColors = /**@type Record<string, ProcessedPaletteColor>*/({});
    paletteEntries
      .forEach(function (entry) {
        entry.palette.colors.forEach(function (color) {
          allColors[color.id] = color;
        });
      });

    var colorIDToIdx = ObjUtil.fromEntries(ObjUtil.entries(allColors)
      .map(function (entry, index) { return { key: entry.key, value: index }; }));
    var paletteIdxToColors = paletteEntries.map(function (paletteColorIDs) {
      return paletteColorIDs.palette.colors.map(function (color) { return { data: color.data, idx: colorIDToIdx[color.id] } });
    });

    /** A paletteGroup describes a collection of palettes where each palette shares some of the same set of colorIDs. Each group can process permutations independantly.*/
    var paletteGroups = /**@type {{ paletteIdxs: number[], nodePaths: NodePath[], colorIdxs: number[] }[]} */([]);
    paletteIdxToColors
      .forEach(function (colors, paletteIdx) {
        var nodePaths = paletteEntries[paletteIdx].nodePaths;
        var groupIdx = new Iter(paletteGroups)
          .findIndex(function (paletteGroup) {
            return colors.some(function (color) {
              return paletteGroup.colorIdxs.indexOf(color.idx) >= 0;
            }) && nodePaths.some(function (nodePath) {
              return paletteGroup.nodePaths.indexOf(nodePath) >= 0;
            });
          });
        if (groupIdx != null)
        {
          paletteGroups[groupIdx] = {
            paletteIdxs: paletteGroups[groupIdx].paletteIdxs.concat([paletteIdx]),
            nodePaths: paletteGroups[groupIdx].nodePaths.concat(nodePaths),
            colorIdxs: paletteGroups[groupIdx].colorIdxs.concat(colors.map(function (color) { return color.idx; })),
          };
          return;
        }
        paletteGroups.push({
          paletteIdxs: [paletteIdx],
          nodePaths: nodePaths,
          colorIdxs: colors.map(function (color) { return color.idx; }),
        });
      });

    var groupSelections = paletteGroups
      .map(function (paletteGroup) {
        // Input into permutations algorithm goes n! - must be capped to prevent hanging.
        var trimmedPaletteIdxs = paletteGroup.paletteIdxs.slice(0, 8);

        var uniquePermutationSet = /**@type Record<string, number[]>*/({});
        Iter.allPermuations(trimmedPaletteIdxs)
          .forEach(function (permutation) {

            var colorIdxToColorDataToPaletteIdx = /**@type Array<Record<string, number>>*/({});
            permutation.forEach(function (paletteIdx) {
              var entry = paletteEntries[paletteIdx];
              entry.palette.colors.forEach(function (color) {
                var colorIdx = colorIDToIdx[color.id];
                var colorDataToPaletteIdx = colorIdxToColorDataToPaletteIdx[colorIdx];
                if (colorDataToPaletteIdx == null)
                {
                  colorDataToPaletteIdx = {};
                  colorIdxToColorDataToPaletteIdx[colorIdx] = colorDataToPaletteIdx;
                }
                if (colorDataToPaletteIdx[color.data] == null)
                {
                  colorDataToPaletteIdx[color.data] = paletteIdx;
                }
              });
            });

            var colorIdxToPaletteIdx = /**@type number[]*/([]);
            var reversePaletteIdxs = permutation.concat([]).reverse();
            reversePaletteIdxs.forEach(function (paletteIdx) {
              paletteIdxToColors[paletteIdx].forEach(function (color) {
                colorIdxToPaletteIdx[color.idx] = colorIdxToColorDataToPaletteIdx[color.idx][color.data];
              });
            });

            var outputColorKey = String.fromCharCode.apply(null, colorIdxToPaletteIdx);
            var usedPaletteIdxSet = /**@type Record<number, boolean>*/({});
            colorIdxToPaletteIdx
              .forEach(function (paletteIdx) { usedPaletteIdxSet[paletteIdx] = true; });
            uniquePermutationSet[outputColorKey] = permutation
              .filter(function (paletteIdx) { return usedPaletteIdxSet[paletteIdx]; });
          });

        var result = ObjUtil.values(uniquePermutationSet).map(function (permutation) {
          return permutation.map(function (palette) {
            return paletteEntries[palette].palette.id;
          });
        });

        // Input into variations algorithm goes n^m - must be capped to prevent hanging.
        return result.slice(0, 32);
      });

    return Iter.allVariations(groupSelections);
  }

  /**
   * @param {Palette} palette
   * @returns {ProcessedPalette}
   */
  function processPalette(palette) {
    var colors = [];
    for (var colorIdx = 0; colorIdx < palette.nColors; colorIdx++)
    {
      var color = palette.getColorByIndex(colorIdx);
      var colorDataJSON = Array.isArray(color.colorData) ? color.colorData[0] : color.colorData;
      var colorData = colorDataJSON == null ? null : [colorDataJSON.r, colorDataJSON.g, colorDataJSON.b, colorDataJSON.a];
      var colorDataLookup = colorData == null ? "" : String.fromCharCode.apply(null, colorData);
      colors.push({ id: color.id, data: colorDataLookup });
    }
    return { id: palette.id, colors: colors };
  }
}