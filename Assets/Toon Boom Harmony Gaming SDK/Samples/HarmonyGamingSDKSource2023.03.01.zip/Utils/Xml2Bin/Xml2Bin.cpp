
#include "Base/MEM_Override.h"

#include "Base/IO_PersistentStore.h"
#include "Base/IO_File.h"
#include "Base/IO_Memory.h"
#include "Base/UT_String.h"
#include "Xml/XML_ProjectLoader.h"
#include "Render/RD_ClipDataCore.h"
#include "Render/RD_SpriteSheetCore.h"
#include "Tree/TR_NodeTree.h"
#include "XML_StageSaxParser.h"
#include "XML_BinaryHeader.h"

#include <set>
#include <iostream>
#include <Base/IO_Buffer.h>
#include <cstdarg>

// Which platform we are on?
#if _MSC_VER && !NN_NINTENDO_SDK
#define UNITY_WIN 1
#else
#define UNITY_NOT_WIN 1
#endif

// Attribute to make function be exported from a plugin
#if UNITY_WIN || TARGET_PS4
#define EXPORT_API __declspec(dllexport)
#else
#define EXPORT_API
#endif


//https://stackoverflow.com/a/8098080
STD_String string_format(const STD_String fmt, ...) {
	int size = ((int)fmt.size()) * 2 + 50;   // Use a rubric appropriate for your code
	STD_String str;
	va_list ap;
	while (1) {     // Maximum two passes on a POSIX system...
		str.resize(size);
		va_start(ap, fmt);
		int n = vsnprintf((char*)str.data(), size, fmt.c_str(), ap);
		va_end(ap);
		if (n > -1 && n < size) {  // Everything worked
			str.resize(n);
			return str;
		}
		if (n > -1)  // Needed size returned
			size = n + 1;   // For null char
		else
			size *= 2;      // Guess at a larger size (OS specific)
	}
	return str;
}

void Run(
	IO_Stream &output,
	const STD_String &projectFolder,
	int(stdprint)(char const* const str),
	int(errprint)(char const* const str))
{
	IO_PersistentStore store(output);
	// Write placeholder header
	XML_BinaryHeader header = XML_BinaryHeader();
	header.store(store);

	//Clips
	{
		//  Load clips
		stdprint("Loading stage clips XML...\n");
		XML_ProjectLoader::ClipDataCol_t clipNames;
		XML_ProjectLoader::loadStageClipNames(projectFolder, clipNames);

		// Write clip names
		stdprint(string_format("Writing %d clip names to binary...\n", clipNames.size()).c_str());
		header.clipSize = clipNames.size();
		header.clipOffset = output.tell();
		for (XML_ProjectLoader::ClipDataCol_t::const_iterator i = clipNames.begin(), iEnd = clipNames.end(); i != iEnd; ++i)
		{
			const XML_StageNamesSaxParser::ClipData clipName = *i;
			store << clipName.displayName;
			store << clipName.fullName;
			store << clipName.name;

			stdprint(string_format("Recording '%s' to index.\n", clipName.displayName.c_str()).c_str());

			RD_ClipDataCore clipData;
			XML_ProjectLoader::loadStageClip(projectFolder, clipName.fullName, &clipData);

			store << clipData.totalDuration();
			store << clipName.isProp;
		}


		// Write clips
		stdprint(string_format("Writing %d clips to binary...\n", clipNames.size()).c_str());
		header.fullClipSize = clipNames.size();
		header.fullClipOffset = output.tell();
		for (XML_ProjectLoader::ClipDataCol_t::const_iterator i = clipNames.begin(), iEnd = clipNames.end(); i != iEnd; ++i)
		{
			const XML_StageNamesSaxParser::ClipData clipName = *i;

			stdprint(string_format("Converting clip '%s' to binary.\n", clipName.fullName.c_str()).c_str());

			RD_ClipDataCore clipData;
			XML_ProjectLoader::loadStageClip(projectFolder, clipName.fullName, &clipData);

			clipData.store(store);
		}

		stdprint("Done stage clips.\n");
	}

	//Sheets
	if (XML_ProjectLoader::hasSpriteSheet(projectFolder))
	{
		//  Load sheet names
		stdprint("Loading spritesheets XML...\n");
		XML_ProjectLoader::StringPairCol_t sheetNames;
		XML_ProjectLoader::loadSpriteSheetNames(projectFolder, sheetNames);

		// Write sheet names
		stdprint(string_format("Writing %d spritesheet names to binary...\n", sheetNames.size()).c_str());
		header.sheetSize = sheetNames.size();
		header.sheetOffset = output.tell();
		for (XML_ProjectLoader::StringPairCol_t::const_iterator i = sheetNames.begin(), iEnd = sheetNames.end(); i != iEnd; ++i)
		{
			STD_String sheetName = i->first;
			STD_String sheetResolution = i->second;
			store << sheetName;
			store << sheetResolution;
		}

		// Write sheets
		stdprint(string_format("Writing %d spritesheets to binary...\n", sheetNames.size()).c_str());
		header.fullSheetSize = sheetNames.size();
		header.fullSheetOffset = output.tell();
		for (XML_ProjectLoader::StringPairCol_t::const_iterator i = sheetNames.begin(), iEnd = sheetNames.end(); i != iEnd; ++i)
		{
			STD_String sheetName = i->first;
			STD_String sheetResolution = i->second;

			stdprint(string_format("Converting sprite sheet '%s' with resolution '%s' to binary.\n", sheetName.c_str(), sheetResolution.c_str()).c_str());

			RD_SpriteSheetCore sheet;
			XML_ProjectLoader::loadSpriteSheet(projectFolder, sheetName, sheetResolution, &sheet);
			sheet.store(store);
		}

		stdprint("Done spritesheets.\n");
	}
	else
	{
		// Read sprites info
		STD_Vector<XML_SpritesSaxParser::CropInfo> cropInfoCol = STD_Vector<XML_SpritesSaxParser::CropInfo>();
		stdprint("Loading individual sprite XML...\n");
		XML_ProjectLoader::loadSprites(projectFolder, cropInfoCol);

		// Write sprites info
		stdprint(string_format("Writing %d individual sprite data to binary...\n", cropInfoCol.size()).c_str());
		header.singleSpritesSize = cropInfoCol.size();
		header.singleSpritesOffset = output.tell();
		for (STD_Vector<XML_SpritesSaxParser::CropInfo>::const_iterator i = cropInfoCol.begin(), iEnd = cropInfoCol.end(); i != iEnd; ++i)
		{
			i->store(store);
		}
		stdprint("Done individual sprites.\n");
	}

	//Nodes, Skins and Groups
	{
		//  Load skin names
		stdprint("Loading nodes, skins and groups XML...\n");
		XML_ProjectLoader::HarmonyNodeCol_t harmonyNodes;
		XML_ProjectLoader::HarmonyIdCol_t skinNames;
		XML_ProjectLoader::HarmonyIdCol_t groupNames;
		XML_ProjectLoader::loadSkinNames(projectFolder, harmonyNodes, skinNames, groupNames);

		// Write harmony nodes
		stdprint(string_format("Writing %d nodes to binary...\n", harmonyNodes.size()).c_str());
		header.nodeSize = harmonyNodes.size();
		header.nodeOffset = output.tell();
		for (XML_ProjectLoader::HarmonyNodeCol_t::const_iterator i = harmonyNodes.begin(), iEnd = harmonyNodes.end(); i != iEnd; ++i)
		{
			i->store(store);
		}

		// Write skins
		stdprint(string_format("Writing %d skins to binary...\n", skinNames.size()).c_str());
		header.skinsSize = skinNames.size();
		header.skinsOffset = output.tell();
		for (XML_ProjectLoader::HarmonyIdCol_t::const_iterator i = skinNames.begin(), iEnd = skinNames.end(); i != iEnd; ++i)
		{
			const STD_Pair<int, STD_String> skin = *i;
			store << skin.second;
			store << skin.first;
		}

		// Write groups
		stdprint(string_format("Writing %d groups to binary...\n", groupNames.size()).c_str());
		header.groupSize = groupNames.size();
		header.groupOffset = output.tell();
		for (XML_ProjectLoader::HarmonyIdCol_t::const_iterator i = groupNames.begin(), iEnd = groupNames.end(); i != iEnd; ++i)
		{
			const STD_Pair<int, STD_String> group = *i;
			store << group.second;
			store << group.first;
		}

		stdprint("Done nodes, skins and groups.\n");
	}

	//Props, Anchors and Metas
	{
		//  Load metas
		stdprint("Loading props, anchors and metas XML...\n");
		XML_ProjectLoader::StringPairCol_t props;
		XML_ProjectLoader::StringPairCol_t anchors;
		XML_ProjectLoader::GenericMetaCol_t metas;
		XML_ProjectLoader::loadMetas(projectFolder, props, anchors, metas);

		// Write props names
		stdprint(string_format("Writing %d props to binary...\n", props.size()).c_str());
		header.propsSize = props.size();
		header.propsOffset = output.tell();
		for (XML_ProjectLoader::StringPairCol_t::const_iterator i = props.begin(), iEnd = props.end(); i != iEnd; ++i)
		{
			const STD_Pair<STD_String, STD_String> prop = *i;
			store << prop.first;
			store << prop.second;
		}

		// Write anchors names
		stdprint(string_format("Writing %d anchors to binary...\n", anchors.size()).c_str());
		header.anchorsSize = anchors.size();
		header.anchorsOffset = output.tell();
		for (XML_ProjectLoader::StringPairCol_t::const_iterator i = anchors.begin(), iEnd = anchors.end(); i != iEnd; ++i)
		{
			const STD_Pair<STD_String, STD_String> anchor = *i;
			store << anchor.first;
			store << anchor.second;
		}

		// Write meta names
		stdprint(string_format("Writing %d metas to binary...\n", metas.size()).c_str());
		header.metasSize = metas.size();
		header.metasOffset = output.tell();
		for (XML_ProjectLoader::GenericMetaCol_t::const_iterator i = metas.begin(), iEnd = metas.end(); i != iEnd; ++i)
		{
			i->store(store);
		}

		stdprint("Done props, anchors and metas.\n");
	}

	//Update header
	output.seek(0);
	header.store(store);
	stdprint("All done.\n");
}

extern "C" int EXPORT_API ConvertToFile(
	const char* projectPath, 
	const char* bytesFilePath, 
	int(stdprint)(char const* const str),
	int(errprint)(char const* const str))
{
#ifdef MEM_DEBUG_OVERRIDE
	MEM_DebugOverride::initialize();
#endif
	STD_String projectFolder(projectPath);
	STD_String outputFileName(bytesFilePath);

	if (!ghc::filesystem::is_directory(projectFolder))
	{
		errprint(string_format("Could not find folder '%s'\n", projectFolder.c_str()).c_str());
#ifdef MEM_DEBUG_OVERRIDE
		MEM_DebugOverride::deinitialize();
#endif
		return -1;
	}

	IO_File outputFile;
	if (outputFile.createForOutput(outputFileName))
	{
		stdprint(string_format("Converting project at %s to binary file %s.\n", projectFolder.c_str(), outputFileName.c_str()).c_str());

		Run(outputFile, projectFolder, stdprint, errprint);

		outputFile.close();
	}

#ifdef MEM_DEBUG_OVERRIDE
	MEM_DebugOverride::deinitialize();
#endif
    
    return 0;
}

extern "C" int EXPORT_API ConvertToMemory(
	const char* projectPath, 
	void* &bytesBuffer,
	size_t &bytesBufferSize, 
	int(stdprint)(char const* const str),
	int(errprint)(char const* const str))
{
#ifdef MEM_DEBUG_OVERRIDE
	MEM_DebugOverride::initialize();
#endif
	STD_String projectFolder(projectPath);

	if (!ghc::filesystem::is_directory(projectFolder))
	{
		errprint(string_format("Could not find folder '%s'\n", projectFolder.c_str()).c_str());
#ifdef MEM_DEBUG_OVERRIDE
		MEM_DebugOverride::deinitialize();
#endif
		return -1;
	}

	IO_Buffer outputBuffer(0x400000, 0x100000);

	Run(outputBuffer, projectFolder, stdprint, errprint);

	outputBuffer.close(bytesBuffer, bytesBufferSize);

#ifdef MEM_DEBUG_OVERRIDE
	MEM_DebugOverride::deinitialize();
#endif
    
    return 0;
}

extern "C" void EXPORT_API FreeMemoryBuffer(
	void* returnedBytesBuffer,
	int(stdprint)(char const* const str),
	int(errprint)(char const* const str))
{
#ifdef MEM_DEBUG_OVERRIDE
	MEM_DebugOverride::initialize();
#endif
	free(returnedBytesBuffer);
#ifdef MEM_DEBUG_OVERRIDE
	MEM_DebugOverride::deinitialize();
#endif
}


int printf_stdout(char const* const str)
{
	return(fprintf(stdout, str));
}

int printf_stderr(char const* const str)
{
	return(fprintf(stderr, str));
}

void usage()
{
	STD_String howto(
		"Usage: Xml2Bin [sceneFolder] [outputFile]\n"
		"\n"
		"This program converts the xml data in the specified scene folder to\n"
		"optimized binary files.\n"
		"\n"
		"Options:\n"
		"  -?|-h|-help|--help \n"
	);

	printf("%s", howto.c_str());
}

int main(int /*argc*/, char *argv[])
{
	if (*argv) ++argv; // skip the program name
	while (*argv && **argv == '-')
	{
		STD_String arg(*argv);

		if (arg.compare("-help") == 0 ||
			arg.compare("-?") == 0 ||
			arg.compare("-h") == 0 ||
			arg.compare("--help") == 0)
		{
			usage();
			return 0;
		}

		//  For if we have options
		++argv;
	}

	if (!argv[0])
	{
		fprintf(stderr, "No scene folder specified.\n");
		usage();
		return -1;
	}

	if (!argv[1])
	{
		fprintf(stderr, "No output file specified.\n");
		usage();
		return -1;
	}

	ConvertToFile(argv[0], argv[1], printf_stdout, printf_stderr);
}
