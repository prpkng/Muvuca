#include "TV_FloatDataView.h"

TV_FloatDataView::TV_FloatDataView()
{
}

TV_FloatDataView::~TV_FloatDataView()
{
}
