#include "XML_BinaryHeader.h"

void XML_BinaryHeader::store(IO_PersistentStore& store)
{
	char* ptr = (char*)this;
	for (int i = 0; i < sizeof(XML_BinaryHeader); i++)
	{
		store << *ptr++;
	}
}

void XML_BinaryHeader::read(IO_PersistentStore& store)
{
	char* ptr = (char*)this;
	for (int i = 0; i < sizeof(XML_BinaryHeader); i++)
	{
		store >> *ptr++;
	}
}