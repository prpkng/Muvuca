#ifndef _XML_STAGE_SAX_PARSER_H_
#define _XML_STAGE_SAX_PARSER_H_

#include "XML_SaxParser.h"
#include "IO_PersistentStore.h"

#include "Base/MEM_Override.h"
#include "Base/STD_Containers.h"
#include "Base/STD_Types.h"

class RD_ClipDataCore;

/*!
 *  @class XML_StageSaxParser
 *  XML Parser for stage clip.
 */
class XML_StageSaxParser : public XML_SaxParserComponent
{
  MEM_OVERRIDE

public:

  enum State
  {
    eRoot,
    eStages,
    eStage
  };

public:
  XML_StageSaxParser( const STD_String &projectFolder, const STD_String &clipName, RD_ClipDataCore *clip );
  virtual ~XML_StageSaxParser();

  virtual XML_SaxParserComponentPtr_t startComponent(const char *nodeName, const XML_AttributeCol_t &attributes);
  virtual void endComponent(const char *nodeName);

private:

  STD_String           _projectFolder;
  State                _state;

  RD_ClipDataCore *_clip;
};

/*!
 *  @class XML_StageNamesSaxParser
 *  XML Parser for stage name collection.
 */
class XML_StageNamesSaxParser : public XML_SaxParserComponent
{
  MEM_OVERRIDE

public:

    struct ClipData
    {
        STD_String displayName;
        STD_String fullName;
        STD_String name;
        bool isProp;

    public:
        ClipData(STD_String displayName, STD_String fullName, STD_String name, bool isProp) :
            displayName(displayName),
            fullName(fullName),
            name(name),
            isProp(isProp)
        {}
    };

  enum State
  {
    eRoot,
    eStages,
    eStage,
    eProps
  };

  typedef STD_Vector< ClipData > ClipDataCol_t;

public:
  XML_StageNamesSaxParser( const STD_String &projectFolder, ClipDataCol_t &clipNames );
  virtual ~XML_StageNamesSaxParser();

  virtual XML_SaxParserComponentPtr_t startComponent(const char *nodeName, const XML_AttributeCol_t &attributes);
  virtual void endComponent(const char *nodeName);

private:

  STD_String   _projectFolder;
  STD_String   _parentName;
  State        _state;

  ClipDataCol_t&_clipData;
};

/*!
 *  @class XML_StageNamesSaxParser
 *  XML Parser for stage name collection.
 */
class XML_SkinsNamesSaxParser : public XML_SaxParserComponent
{
    MEM_OVERRIDE

public:

    struct HarmonyNode
    {
        int id;
        STD_String name;
        STD_Vector< int > skinIds;
        int groupId;

    public:
        HarmonyNode() :
            HarmonyNode(STD_Vector<int>())
        {}

        HarmonyNode(STD_Vector<int> skinIds, STD_String name = "", int groupId = 0, int id = 0) :
            id(id),
            name(name),
            skinIds(skinIds),
            groupId(groupId)
        {}

        void store(IO_PersistentStore& store) const
        {
            store << name;
            store << (int)skinIds.size();
            for (STD_Vector<int>::const_iterator j = skinIds.begin(), iEnd = skinIds.end(); j != iEnd; ++j)
            {
                store << *j;
            }
            store << groupId;
            store << id;
        }
    };

    enum State
    {
        eRoot,
        eStages,
        eStage
    };

    typedef STD_Vector< HarmonyNode > HarmonyNodeCol_t;
    typedef STD_Vector< STD_Pair<int, STD_String> > HarmonyIdCol_t;

public:
    XML_SkinsNamesSaxParser(const STD_String& projectFolder, HarmonyNodeCol_t& nodes, HarmonyIdCol_t& skinNames, HarmonyIdCol_t& groupNames);
    virtual ~XML_SkinsNamesSaxParser();

    virtual XML_SaxParserComponentPtr_t startComponent(const char* nodeName, const XML_AttributeCol_t& attributes);
    virtual void endComponent(const char* nodeName);

private:

    STD_String   _projectFolder;
    State        _state;

    HarmonyNodeCol_t &_nodes;
    HarmonyIdCol_t &_skinNames;
    HarmonyIdCol_t &_groupNames;
};


/*!
 *  @class XML_MetaSaxParserComponent
 *  XML Parser for stage name collection.
 */
class XML_MetaSaxParserComponent : public XML_SaxParserComponent
{
    MEM_OVERRIDE

public:

    struct GenericMeta
    {
        STD_String name;
        STD_String clipName;
        STD_String playName;
        STD_String nodeName;
        STD_String value;

    public:
        GenericMeta(STD_String name, STD_String clipName, STD_String playName, STD_String nodeName, STD_String value) :
            name(name),
            clipName(clipName),
            playName(playName),
            nodeName(nodeName),
            value(value)
        {}

        void store(IO_PersistentStore & store) const
        {
            store << name;
            store << clipName;
            store << playName;
            store << nodeName;
            store << value;
        }
    };

    enum State
    {
        eRoot,
        eStages,
        eStage
    };
    typedef STD_Vector< STD_Pair< STD_String, STD_String > > StringPairsCol_t;
    typedef STD_Vector< GenericMeta > GenericMetaCol_t;

public:
    XML_MetaSaxParserComponent(const STD_String& projectFolder, StringPairsCol_t& props, StringPairsCol_t& anchors, GenericMetaCol_t& metas);
    virtual ~XML_MetaSaxParserComponent();

    virtual XML_SaxParserComponentPtr_t startComponent(const char* nodeName, const XML_AttributeCol_t& attributes);
    virtual void endComponent(const char* nodeName);

private:

    STD_String   _projectFolder;
    State        _state;
    STD_String   _clipName;

    StringPairsCol_t& _props;
    StringPairsCol_t& _anchors;
    GenericMetaCol_t& _metas;
};

#endif /* _XML_STAGE_SAX_PARSER_H_ */
