
#include "IO_Stream.h"

IO_Stream::~IO_Stream()
{
}
