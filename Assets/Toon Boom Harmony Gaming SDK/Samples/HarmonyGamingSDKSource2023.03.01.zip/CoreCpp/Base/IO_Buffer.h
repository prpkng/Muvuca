#ifndef _IO_BUFFER_H_
#define _IO_BUFFER_H_

#include "IO_Stream.h"
#include "MEM_Override.h"

/*!
 *  @class IO_Buffer
 *  Stream onto a byte buffer
 */
class IO_Buffer : public IO_Stream
{
	MEM_OVERRIDE

public:
	IO_Buffer(size_t initialSize, size_t extensionBlockSize = 0x200);
	virtual ~IO_Buffer();

	void close(void*& ptr, size_t& size);

	// IO_Stream interface
	virtual size_t       read(void* lpBuf, size_t nCount);
	virtual void         write(const void* lpBuf, size_t nCount);
	virtual void         seek(size_t addr);
	virtual size_t       tell();
	virtual void         reset();
	virtual bool	     isEOF();
	virtual size_t       size() const;

	virtual UT_String    streamName() const;

private:

	//  non-implemented constructors.
	IO_Buffer(const IO_Buffer&);
	IO_Buffer&operator= (const IO_Buffer&);

private:

	class Impl;
	Impl *_i;
};

#endif // _IO_BUFFER_H_
