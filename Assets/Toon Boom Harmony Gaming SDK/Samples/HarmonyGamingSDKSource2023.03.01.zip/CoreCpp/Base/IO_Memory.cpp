#include "IO_Memory.h"
#include "UT_String.h"

#include <stdio.h>
#include <string.h>

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#if 0
#pragma mark - IO_Memory::Impl
#endif
class IO_Memory::Impl
{
	MEM_OVERRIDE

	friend class IO_Memory;

public:

	Impl(const void *memory, size_t size)
		: _memory((char*)memory), _totalSize(size), _currentPosition(0)
	{
	}

	~Impl()
	{
	}

private:

	const char *_memory;
	size_t _totalSize;
	size_t _currentPosition;
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#if 0
#pragma mark - IO_File::Impl
#endif

IO_Memory::IO_Memory(const void *memory, size_t size)
{
	_i = new Impl(memory, size);
}

IO_Memory::~IO_Memory()
{
	delete _i;
}

size_t IO_Memory::read(void* lpBuf, size_t nCount)
{
	size_t readAvailable = _i->_totalSize - _i->_currentPosition;
	size_t readAmount = nCount <= readAvailable ? nCount : readAvailable;
	memcpy(lpBuf, &_i->_memory[_i->_currentPosition], readAmount);
	_i->_currentPosition += readAmount;
	return readAmount;
}

void IO_Memory::write(const void* lpBuf, size_t nCount)
{
}

void IO_Memory::seek(size_t addr)
{
	_i->_currentPosition = addr;
}

size_t IO_Memory::tell()
{
	return _i->_currentPosition;
}

void IO_Memory::reset()
{
	_i->_currentPosition = 0;
}

bool IO_Memory::isEOF()
{
	return _i->_currentPosition == _i->_totalSize;
}

size_t IO_Memory::size() const
{
	return _i->_totalSize;
}

UT_String IO_Memory::streamName() const
{
	return UT_String("Memory");
}

