#!/bin/sh
echo ""

echo "Cleanup"
rm -rf arm/obj/ arm/libs/

echo ""
echo "Compiling for achitecture 'arm'"
$ANDROID_NDK_ROOT/ndk-build -d NDK_PROJECT_PATH=arm NDK_APPLICATION_MK=Application-arm.mk $*

echo "Cleanup"
rm -rf x86/obj/ x86/libs/

echo ""
echo "Compiling for achitecture 'x86'"
$ANDROID_NDK_ROOT/ndk-build -d NDK_PROJECT_PATH=x86 NDK_APPLICATION_MK=Application-x86.mk $*

echo ""
echo "Done!"
