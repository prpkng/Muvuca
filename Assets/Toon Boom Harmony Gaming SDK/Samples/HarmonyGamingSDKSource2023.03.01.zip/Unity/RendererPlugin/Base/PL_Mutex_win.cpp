
#include "PL_Mutex.h"

#if !defined(SUPPORT_CXX11_STANDARD) && defined(TARGET_WIN32)

#include <windows.h>
#include <stdio.h>

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#if 0
#pragma mark - PL_Mutex::Impl
#endif
class PL_Mutex::Impl
{
  friend class PL_Mutex;

public:

  Impl()
  {
  }

  ~Impl()
  {
  }

private:

  HANDLE _mutex;
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#if 0
#pragma mark - PL_Mutex
#endif

PL_Mutex::PL_Mutex()
{
  _i = new Impl;

  _i->_mutex = CreateMutex( NULL /*default security attributes*/, FALSE /*not owned*/, NULL /*unnamed*/ );
  
  if ( _i->_mutex == NULL )
    fprintf( stderr, "Error in mutex initialization!\n" );
}

PL_Mutex::~PL_Mutex()
{
  CloseHandle(_i->_mutex);
  
  delete _i;
}

void PL_Mutex::lock()
{
  WaitForSingleObject( _i->_mutex, INFINITE /*no time-out*/ );
}

bool PL_Mutex::try_lock()
{
  DWORD ret = WaitForSingleObject( _i->_mutex, 0 /*no wait*/ );              
  return (ret == WAIT_OBJECT_0);
}

void PL_Mutex::unlock()
{
  ReleaseMutex(_i->_mutex);
}

#endif
