#include "RD_SpriteSheet.h"
#include "Render/RD_SpriteSheet.h"

#include "Xml/XML_ProjectLoader.h"

#include "Base/STD_Types.h"

#if 0 
#include <fstream>
/*!
 *  Will write the bitmap passed in parameter in a ppm file
 *  named filename
 */
void WritePPMFile(const std::string &filename, const IM_ImagePtr_t &image)
{
	if (image.get() == 0)
		return;

	std::ofstream file(filename.c_str());

	unsigned nBytesPerLine = image->width() * 3;

	file << "P6\n# Creator stage\n";
	file << (nBytesPerLine / 3) << " ";
	file << image->height();
	file << "\n255\n";

	for (unsigned int i = 0; i < image->height(); ++i)
	{
		for (unsigned int j = 0; j < image->width(); ++j)
		{
			file.write((const char *)image->pixel(j, i), 1);
			file.write((const char *)image->pixel(j, i) + 1, 1);
			file.write((const char *)image->pixel(j, i) + 2, 1);
		}
	}

	file.close();
}
#endif

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#if 0
#pragma mark - RD_SpriteSheet::Impl
#endif
class RD_SpriteSheet::Impl
{
	friend class RD_SpriteSheet;

public:
	Impl()
	{
	}

	~Impl()
	{
	}

private:

	int				_projectId;
	RD_SpriteSheetCore *_pSpriteSheet;
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#if 0
#pragma mark - RD_SpriteSheet
#endif

/*RD_SpriteSheetPtr_t RD_SpriteSheet::create( const RD_SpriteSheetKey &key )
{
  RD_SpriteSheetCore *spriteSheetCore = new RD_SpriteSheetCore;

  //  Try to load from binary file, fallback on xml format.
  if ( !BIN_ProjectLoader::loadSpriteSheet( key._projectFolder, key._sheetName, key._resolutionName, spriteSheetCore ) )
	XML_ProjectLoader::loadSpriteSheet( key._projectFolder, key._sheetName, key._resolutionName, spriteSheetCore );

  if ( !spriteSheetCore->empty() )
  {
	RD_SpriteSheetPtr_t pSpriteSheet = new RD_SpriteSheet(key._projectFolder, spriteSheetCore);

	RD_SpriteSheetManager::instance()->addObject(key, pSpriteSheet);

	return pSpriteSheet;
  }

  delete spriteSheetCore;
  return RD_SpriteSheetPtr_t(0);
}

RD_SpriteSheetPtr_t RD_SpriteSheet::createOrLoad( const RD_SpriteSheetKey &key )
{
  RD_SpriteSheetPtr_t pSpriteSheet = RD_SpriteSheetManager::instance()->object( key );

  //  Resolution was changed, try loading new spritesheet.
  if (!pSpriteSheet.isValid())
  {
	pSpriteSheet = RD_SpriteSheet::create(key);
	if ( !pSpriteSheet.isValid() )
	{
	  //  No sprite sheet could be found for sheetResolution.  Try to retrieve valid one.
	  XML_ProjectLoader::StringPairCol_t resolutionNames;
	  XML_ProjectLoader::loadSpriteSheetResolutionNames(key._projectFolder, key._sheetName, resolutionNames );

	  if ( !resolutionNames.empty() )
	  {
		STD_String defaultResolutionName = resolutionNames.front().second;
		RD_SpriteSheetKey defaultKey(key._projectFolder, key._sheetName, defaultResolutionName);
		pSpriteSheet = RD_SpriteSheetManager::instance()->object( defaultKey );
		if ( !pSpriteSheet.isValid() )
		{
		  pSpriteSheet = RD_SpriteSheet::create(defaultKey);
		}
	  }
	}
  }

  return pSpriteSheet;
}*/

RD_SpriteSheet::RD_SpriteSheet(int projectId, RD_SpriteSheetCore *pSpriteSheet)
{
	_i = new Impl;
	_i->_projectId = projectId;
	_i->_pSpriteSheet = pSpriteSheet;  // owned by RD_SpriteSheet.
}

RD_SpriteSheet::~RD_SpriteSheet()
{
	delete _i->_pSpriteSheet;

	delete _i;
}

const RD_SpriteSheet::SpriteData *RD_SpriteSheet::sprite(const STD_String &name) const
{
	return _i->_pSpriteSheet->sprite(name);
}

bool RD_SpriteSheet::rect(const STD_String &name, Rect &rect) const
{
	return _i->_pSpriteSheet->rect(name, rect);
}

bool RD_SpriteSheet::textureId(const STD_String& name, int& textureId) const
{
	return _i->_pSpriteSheet->textureId(name, textureId);
}

bool RD_SpriteSheet::matrix(const STD_String &name, Math::Matrix4x4 &matrix) const
{
	return _i->_pSpriteSheet->matrix(name, matrix);
}

int RD_SpriteSheet::projectId() const
{
	return _i->_projectId;
}

const STD_String &RD_SpriteSheet::sheetName() const
{
	return _i->_pSpriteSheet->sheetName();
}

const STD_String &RD_SpriteSheet::sheetResolution() const
{
	return _i->_pSpriteSheet->sheetResolution();
}

bool RD_SpriteSheet::uvs(const STD_String &name, int& textureId, float &u1, float &v1, float &u2, float &v2) const
{
	Rect r;
	if (rect(name, r) && this->textureId(name, textureId))
	{
		return uvs(r, textureId, u1, v1, u2, v2);
	}

	return false;
}

bool RD_SpriteSheet::uvs(const STD_String &name, int &textureId, float uvs[4]) const
{
	Rect r;
	if (rect(name, r) && this->textureId(name, textureId))
	{
		return this->uvs(r, textureId, uvs[0], uvs[1], uvs[2], uvs[3]);
	}

	return false;
}

bool RD_SpriteSheet::uvs(const Rect &rect, int textureId, float &u1, float &v1, float &u2, float &v2) const
{
	int iwidth = width(textureId);
	int iheight = height(textureId);

	if ((iwidth > 0u) && (iheight > 0u))
	{
		float fwidth = (float)iwidth;
		float fheight = (float)iheight;

		if (fwidth > 0.0f)
		{
			u1 = rect._x / fwidth;
			u2 = (rect._x + rect._w) / fwidth;
		}
		else
		{
			u1 = u2 = 0.0f;
		}

		if (fheight > 0.0f)
		{
			v1 = rect._y / fheight;
			v2 = (rect._y + rect._h) / fheight;
		}
		else
		{
			v1 = v2 = 0.0f;
		}

		return true;
	}

	return false;
}

bool RD_SpriteSheet::uvs(const Rect &rect, int textureId, float uvs[4]) const
{
	return this->uvs(rect, textureId, uvs[0], uvs[1], uvs[2], uvs[3]);
}

unsigned RD_SpriteSheet::width(int textureId) const
{
	int width;
	int height;
	_i->_pSpriteSheet->widthHeight(textureId, width, height);
	return width;
}

unsigned RD_SpriteSheet::height(int textureId) const
{
	int width;
	int height;
	_i->_pSpriteSheet->widthHeight(textureId, width, height);
	return height;
}

