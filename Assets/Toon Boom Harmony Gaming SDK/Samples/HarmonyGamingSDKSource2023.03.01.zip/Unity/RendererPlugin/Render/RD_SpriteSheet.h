#ifndef _RD_SPRITE_SHEET_H_
#define _RD_SPRITE_SHEET_H_

#include "RD_RenderObjectManager.h"

#include "Base/UT_SharedWeakPtr.h"
#include "Base/STD_Types.h"

#include "Render/RD_SpriteSheetCore.h"

// typedef void* RD_TexturePtr_t

class RD_SpriteSheet;
typedef UT_SharedPtr< RD_SpriteSheet > RD_SpriteSheetPtr_t;
typedef UT_SharedWeakPtr< RD_SpriteSheet > RD_SpriteSheetWeakPtr_t;

/*!
 *  @struct RD_SpriteSheetKey
 *  Tuple to identify a unique sprite sheet.
 */
struct RD_SpriteSheetKey
{
  RD_SpriteSheetKey( int projectId, const STD_String &sheetName, const STD_String &resolutionName ) :
	  _projectId(projectId),
    _sheetName(sheetName),
    _resolutionName(resolutionName)
  {
  }

  bool operator< ( const RD_SpriteSheetKey &key ) const
  {
    //  To be reviewed, sorting could probably be improved if
    //  it becomes a bottleneck.
    if (_projectId == key._projectId)
    {
      if ( _sheetName.compare(key._sheetName) == 0 )
      {
        return _resolutionName < key._resolutionName;
      }

      return ( _sheetName < key._sheetName );
    }

    return _projectId < key._projectId;
  }

  int _projectId;
  STD_String _sheetName;
  STD_String _resolutionName;
};

typedef RD_RenderObjectManager<RD_SpriteSheetKey, RD_SpriteSheet> RD_SpriteSheetManager;

/*!
 *  @class RD_SpriteSheet
 *  Sprite Sheet data structure.
 */
class RD_SpriteSheet : public UT_SharedWeakBase
{
public:

  typedef RD_SpriteSheetCore::Rect Rect;
  typedef RD_SpriteSheetCore::SpriteData SpriteData;

public:
  RD_SpriteSheet( int projectId, RD_SpriteSheetCore *spriteSheet );
  virtual ~RD_SpriteSheet();

  //! Retrieve specified named sprite in sprite sheet.
  const SpriteData *sprite( const STD_String &name ) const;

  //! Retrieve specified sprite rectangle in sprite sheet.
  bool rect( const STD_String &name, Rect &sprite ) const;

  //! Retrieve specified sprite textureId.
  bool textureId(const STD_String& name, int& textureId) const;

  //! Retrieve specified sprite matrix in sprite sheet.
  bool matrix( const STD_String &name, Math::Matrix4x4 &matrix ) const;

  //! Retrieve project folder.
  int projectId() const;
  //! Retrieve sprite sheet name.
  const STD_String &sheetName() const;
  //! Retrieve sprite sheet resolution.
  const STD_String &sheetResolution() const;

  //! Retrieve texture uvs of specified sprite.
  bool uvs( const STD_String &name, int& textureId, float &u1, float &v1, float &u2, float &v2 ) const;
  //! Retrieve texture uvs of specified sprite.
  bool uvs( const STD_String &name, int& textureId, float uvs[4] ) const;

  //! Convert rectangle coordinates to texture uvs.
  bool uvs( const Rect &rect, int textureId, float &u1, float &v1, float &u2, float &v2 ) const;
  //! Convert rectangle coordinates to texture uvs.
  bool uvs( const Rect &rect, int textureId, float uvs[4] ) const;

  //! Retrieve sprite sheet image width.
  unsigned width(int textureId) const;
  //! Retrieve sprite sheet image height.
  unsigned height(int textureId) const;

private:

  class Impl;
  Impl *_i;
};

#endif /* _RD_SPRITE_SHEET_H_ */
